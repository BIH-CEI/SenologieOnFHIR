# SenologieToOncoBoxBrustOperation - Kerndatensatz Senologie v0.10.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SenologieToOncoBoxBrustOperation**

## StructureMap: SenologieToOncoBoxBrustOperation 

| | |
| :--- | :--- |
| *Official URL*:https://www.senologie.org/fhir/StructureMap/SenologieToOncoBoxBrustOperation | *Version*:0.10.0 |
| Draft as of 2026-10-12 | *Computable Name*:SenologieToOncoBoxBrustOperation |

 
title: Senologie Procedure + Specimen to OncoBox Brust Operation status: draft 



## Resource Content

```json
{
  "resourceType" : "StructureMap",
  "id" : "SenologieToOncoBoxBrustOperation",
  "url" : "https://www.senologie.org/fhir/StructureMap/SenologieToOncoBoxBrustOperation",
  "version" : "0.10.0",
  "name" : "SenologieToOncoBoxBrustOperation",
  "status" : "draft",
  "date" : "2026-10-12T08:17:48+00:00",
  "publisher" : "Berlin Institute of Health at Charité (BIH)",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "Berlin Institute of Health at Charité (BIH)"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Berlin Institute of Health at Charité (BIH)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org"
    }]
  }],
  "description" : "title: Senologie Procedure + Specimen to OncoBox Brust Operation\r\nstatus: draft",
  "structure" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/Bundle",
    "mode" : "source",
    "alias" : "Bundle"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Procedure",
    "mode" : "source",
    "alias" : "Procedure"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Specimen",
    "mode" : "source",
    "alias" : "Specimen"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Observation",
    "mode" : "source",
    "alias" : "Observation"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/ServiceRequest",
    "mode" : "source",
    "alias" : "ServiceRequest"
  }],
  "group" : [{
    "name" : "MapOperation",
    "typeMode" : "none",
    "documentation" : "Import-only map: no target `uses` declaration — the calling map\r\n(SenologieToOncoBoxBrustPrimaerfall) provides the correct BackboneElement\r\ncontext (primaerfall.operation). Omitting the root-level target type avoids\r\nSM_TARGET_PATH false positives where the validator would resolve property\r\nnames against oncobox-brust-meldung root.\r\n============================================================================\r\nOperation: Procedure (+ Specimen / Observation) -> Operation-Block\r\nPro Brust-Procedure wird ein Operation-Block erzeugt mit OP-Datum,\r\nSeitenlokalisation, OPS-Kodes, Operationsart, Drahtmarkierung, Sentinel,\r\nResidualstatus und Komplikationen.\r\n============================================================================",
    "input" : [{
      "name" : "src",
      "type" : "Procedure",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "BackboneElement",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "SetOpLnr",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "lnr",
        "transform" : "copy",
        "parameter" : [{
          "valueInteger" : 1
        }]
      }],
      "documentation" : "LNR Default 1"
    },
    {
      "name" : "SetOpDatum",
      "source" : [{
        "context" : "src",
        "element" : "performed",
        "variable" : "perf",
        "condition" : "$this.is(dateTime)"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "datum",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "perf"
        }]
      }],
      "documentation" : "Op_Datum"
    },
    {
      "name" : "MapOpDatumPeriod",
      "source" : [{
        "context" : "src",
        "element" : "performed",
        "variable" : "perf",
        "condition" : "$this.is(Period)"
      }],
      "rule" : [{
        "name" : "SetOpDatumPeriod",
        "source" : [{
          "context" : "perf",
          "element" : "start",
          "variable" : "s"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "datum",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "s"
          }]
        }]
      }]
    },
    {
      "name" : "MapOpSeite",
      "source" : [{
        "context" : "src",
        "element" : "bodySite",
        "variable" : "bs"
      }],
      "rule" : [{
        "name" : "MapOpSeiteSCT",
        "source" : [{
          "context" : "bs",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'http://snomed.info/sct'"
        }],
        "rule" : [{
          "name" : "SetOpSeiteR",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '24028007'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "seitenlokalisation",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "R"
            }]
          }]
        },
        {
          "name" : "SetOpSeiteL",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '7771000'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "seitenlokalisation",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "L"
            }]
          }]
        },
        {
          "name" : "SetOpSeiteB",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '51440002'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "seitenlokalisation",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "B"
            }]
          }]
        }]
      }],
      "documentation" : "Op_Seite"
    },
    {
      "name" : "MapOpsCodes",
      "source" : [{
        "context" : "src",
        "element" : "code",
        "variable" : "code"
      }],
      "rule" : [{
        "name" : "MapOpsCoding",
        "source" : [{
          "context" : "code",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'http://fhir.de/CodeSystem/bfarm/ops'"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "opsCodes",
          "variable" : "ops"
        }],
        "rule" : [{
          "name" : "SetOpsCode",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd"
          }],
          "target" : [{
            "context" : "ops",
            "contextType" : "variable",
            "element" : "code",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "cd"
            }]
          }]
        },
        {
          "name" : "SetOpsVer",
          "source" : [{
            "context" : "c",
            "element" : "version",
            "variable" : "v"
          }],
          "target" : [{
            "context" : "ops",
            "contextType" : "variable",
            "element" : "version",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "v"
            }]
          }]
        }]
      }],
      "documentation" : "OPS-Kodes"
    },
    {
      "name" : "MapOpArt",
      "source" : [{
        "context" : "src",
        "element" : "code",
        "variable" : "code"
      }],
      "rule" : [{
        "name" : "MapOpArtOPS",
        "source" : [{
          "context" : "code",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'http://fhir.de/CodeSystem/bfarm/ops'"
        }],
        "rule" : [{
          "name" : "SetOpArtBET",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this.startsWith('5-870')"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "operationsart",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "1"
            }]
          }]
        },
        {
          "name" : "SetOpArtMastEinf",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this.startsWith('5-871')"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "operationsart",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "2"
            }]
          }]
        },
        {
          "name" : "SetOpArtSSM",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this.startsWith('5-872')"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "operationsart",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "3"
            }]
          }]
        },
        {
          "name" : "SetOpArtNSM",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this.startsWith('5-883')"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "operationsart",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "4"
            }]
          }]
        },
        {
          "name" : "SetOpArtRekon",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this.startsWith('5-885')"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "operationsart",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "6"
            }]
          }]
        },
        {
          "name" : "SetOpArtAxilla",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this.startsWith('5-402')"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "operationsart",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "7"
            }]
          }]
        },
        {
          "name" : "SetOpArtSLNB",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this.startsWith('5-401.1')"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "operationsart",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "8"
            }]
          }]
        }]
      }],
      "documentation" : "Op_Art aus OPS-Prefix\r\n5-870* = BET, 5-871* = Mast einfach, 5-872* = SSM, 5-883* = NSM,\r\n5-885* = Rekon, 5-401.1* = SLNB, 5-402* = Axilla"
    },
    {
      "name" : "MapSentinel",
      "source" : [{
        "context" : "src",
        "element" : "code",
        "variable" : "code"
      }],
      "rule" : [{
        "name" : "MapSentinelOPS",
        "source" : [{
          "context" : "code",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'http://fhir.de/CodeSystem/bfarm/ops'"
        }],
        "rule" : [{
          "name" : "SetSentinelJa",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this.startsWith('5-401.1')"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "sentinel",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "1"
            }]
          }]
        }]
      }],
      "documentation" : "Op_Sentinel durchgefuehrt (OPS 5-401.1*)"
    },
    {
      "name" : "MapAxDiss",
      "source" : [{
        "context" : "src",
        "element" : "code",
        "variable" : "code"
      }],
      "rule" : [{
        "name" : "MapAxDissOPS",
        "source" : [{
          "context" : "code",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'http://fhir.de/CodeSystem/bfarm/ops'"
        }],
        "rule" : [{
          "name" : "SetAxDissJa",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this.startsWith('5-402')"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "axillaDissektion",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "1"
            }]
          }]
        }]
      }],
      "documentation" : "Op_Axdissektion (OPS 5-402*)"
    },
    {
      "name" : "MapROutcome",
      "source" : [{
        "context" : "src",
        "element" : "outcome",
        "variable" : "out"
      }],
      "rule" : [{
        "name" : "MapROutcomeCoding",
        "source" : [{
          "context" : "out",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'http://snomed.info/sct'"
        }],
        "rule" : [{
          "name" : "SetRLokR0",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '122538001'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "residualstatusLokal",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "R0"
            }]
          }]
        },
        {
          "name" : "SetRGesR0",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '122538001'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "residualstatusGesamt",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "R0"
            }]
          }]
        },
        {
          "name" : "SetRLokR1",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '122539009'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "residualstatusLokal",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "R1"
            }]
          }]
        },
        {
          "name" : "SetRGesR1",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '122539009'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "residualstatusGesamt",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "R1"
            }]
          }]
        },
        {
          "name" : "SetRLokR2",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '122540006'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "residualstatusLokal",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "R2"
            }]
          }]
        },
        {
          "name" : "SetRGesR2",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '122540006'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "residualstatusGesamt",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "R2"
            }]
          }]
        },
        {
          "name" : "SetRLokRX",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '122541005'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "residualstatusLokal",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "RX"
            }]
          }]
        },
        {
          "name" : "SetRGesRX",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '122541005'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "residualstatusGesamt",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "RX"
            }]
          }]
        }]
      }],
      "documentation" : "Residualstatus aus Procedure.outcome (SNOMED)"
    },
    {
      "name" : "SetRevisionDefault",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "revisionsOp",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "0"
        }]
      }],
      "documentation" : "Revisionsoperation (OncoBox 2.0)\r\nOp_Revision: 0=nein, 1=ja\r\nAbgeleitet aus: operationsart = 5 (Revision) oder\r\nProcedure.reasonCode enthält \"Revision\" / SNOMED 282032007"
    },
    {
      "name" : "MapRevisionCode",
      "source" : [{
        "context" : "src",
        "element" : "code",
        "variable" : "code"
      }],
      "rule" : [{
        "name" : "MapRevisionOPS",
        "source" : [{
          "context" : "code",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'http://fhir.de/CodeSystem/bfarm/ops'"
        }]
      }]
    },
    {
      "name" : "MapRevisionReason",
      "source" : [{
        "context" : "src",
        "element" : "reasonCode",
        "variable" : "rc"
      }],
      "rule" : [{
        "name" : "MapRevisionReasonSCT",
        "source" : [{
          "context" : "rc",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'http://snomed.info/sct'"
        }],
        "rule" : [{
          "name" : "SetRevisionJaSCT",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = '282032007'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "revisionsOp",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "1"
            }]
          }]
        }]
      },
      {
        "name" : "SetRevisionJaText",
        "source" : [{
          "context" : "rc",
          "element" : "text",
          "variable" : "txt",
          "condition" : "$this.contains('Revision')"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "revisionsOp",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "1"
          }]
        }]
      },
      {
        "name" : "SetRevisionJaNachresekt",
        "source" : [{
          "context" : "rc",
          "element" : "text",
          "variable" : "txt",
          "condition" : "$this.contains('Nachresektion')"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "revisionsOp",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "1"
          }]
        }]
      }]
    },
    {
      "name" : "MapAnzahlR0",
      "source" : [{
        "context" : "src",
        "element" : "outcome",
        "variable" : "out"
      }],
      "rule" : [{
        "name" : "MapAnzahlR0Coding",
        "source" : [{
          "context" : "out",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system.exists()"
        }],
        "rule" : [{
          "name" : "SetAnzahlR0Default",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd",
            "condition" : "$this = 'R0'"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "anzahlEingriffeR0",
            "transform" : "copy",
            "parameter" : [{
              "valueInteger" : 1
            }]
          }]
        }]
      }],
      "documentation" : "Anzahl Eingriffe bis R0 (KB-14, OncoBox 2.0)\r\nOp_Anzahl_bis_R0: Aggregation aller Procedures für dieselbe Condition\r\nbis zum Erreichen von R0. In FML nur als Einzelwert setzbar —\r\ndie tatsächliche Aggregation erfolgt in der CQL-Auswerteschicht.\r\nHier wird der Defaultwert gesetzt: 1 wenn R0, sonst leer."
    },
    {
      "name" : "MapKompIcd",
      "source" : [{
        "context" : "src",
        "element" : "complication",
        "variable" : "comp"
      }],
      "rule" : [{
        "name" : "MapKompIcdCoding",
        "source" : [{
          "context" : "comp",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'http://fhir.de/CodeSystem/bfarm/icd-10-gm'"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "komplikationen",
          "variable" : "komp"
        }],
        "rule" : [{
          "name" : "SetKompIcdCode",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd"
          }],
          "target" : [{
            "context" : "komp",
            "contextType" : "variable",
            "element" : "icdCode",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "cd"
            }]
          }]
        }]
      }],
      "documentation" : "Komplikationen ICD-10: aus Procedure.complication (compl_icd10 Slice)"
    }]
  }]
}

```
