# Präoperative Antibiotikatherapie - Kerndatensatz Senologie v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Präoperative Antibiotikatherapie**

## Extension: Präoperative Antibiotikatherapie 

| | |
| :--- | :--- |
| *Official URL*:https://www.senologie.org/fhir/StructureDefinition/ex-senologie-pre-op-antibiotikatherapie | *Version*:0.9.0 |
| Draft as of 2026-05-11 | *Computable Name*:EX_Senologie_PreOpAntibiotikatherapie |

Präoperative Antibiotikatherapie — kein natives FHIR-Äquivalent

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [BIH Senologie OP Planung](StructureDefinition-senologie-op-planung.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/kds-senologie|current/StructureDefinition/ex-senologie-pre-op-antibiotikatherapie)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ex-senologie-pre-op-antibiotikatherapie.csv), [Excel](StructureDefinition-ex-senologie-pre-op-antibiotikatherapie.xlsx), [Schematron](StructureDefinition-ex-senologie-pre-op-antibiotikatherapie.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ex-senologie-pre-op-antibiotikatherapie",
  "url" : "https://www.senologie.org/fhir/StructureDefinition/ex-senologie-pre-op-antibiotikatherapie",
  "version" : "0.9.0",
  "name" : "EX_Senologie_PreOpAntibiotikatherapie",
  "title" : "Präoperative Antibiotikatherapie",
  "status" : "draft",
  "date" : "2026-05-11T18:43:40+00:00",
  "publisher" : "Berlin Institute of Health at Charité (BIH)",
  "contact" : [{
    "name" : "Berlin Institute of Health at Charité (BIH)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org"
    }]
  }],
  "description" : "Präoperative Antibiotikatherapie — kein natives FHIR-Äquivalent",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Element"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Präoperative Antibiotikatherapie",
      "definition" : "Präoperative Antibiotikatherapie — kein natives FHIR-Äquivalent"
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://www.senologie.org/fhir/StructureDefinition/ex-senologie-pre-op-antibiotikatherapie"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "string"
      },
      {
        "code" : "CodeableConcept"
      }]
    }]
  }
}

```
