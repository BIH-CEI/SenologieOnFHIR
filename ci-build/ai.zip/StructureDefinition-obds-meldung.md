# oBDS Meldung - Kerndatensatz Senologie v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **oBDS Meldung**

## Logical Model: oBDS Meldung 

| | |
| :--- | :--- |
| *Official URL*:https://www.senologie.org/fhir/StructureDefinition/obds-meldung | *Version*:0.1.0 |
| Draft as of 2026-05-04 | *Computable Name*:OBDSMeldung |

 
Logisches Modell einer oBDS-Meldung (Onkologischer Basisdatensatz v3.0.5). Bildet die XML-Struktur einer einzelnen Meldung ab, wie sie von Meldestellen an die Krebsregister übermittelt wird. 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/kds-senologie|current/StructureDefinition/obds-meldung)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-obds-meldung.csv), [Excel](StructureDefinition-obds-meldung.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "obds-meldung",
  "url" : "https://www.senologie.org/fhir/StructureDefinition/obds-meldung",
  "version" : "0.1.0",
  "name" : "OBDSMeldung",
  "title" : "oBDS Meldung",
  "status" : "draft",
  "date" : "2026-05-04T11:47:21+00:00",
  "publisher" : "Berlin Institute of Health at Charité (BIH)",
  "contact" : [{
    "name" : "Berlin Institute of Health at Charité (BIH)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org"
    }]
  }],
  "description" : "Logisches Modell einer oBDS-Meldung (Onkologischer Basisdatensatz v3.0.5). Bildet die XML-Struktur einer einzelnen Meldung ab, wie sie von Meldestellen an die Krebsregister übermittelt wird.",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://www.senologie.org/fhir/StructureDefinition/obds-meldung",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "obds-meldung",
      "path" : "obds-meldung",
      "short" : "oBDS Meldung",
      "definition" : "Logisches Modell einer oBDS-Meldung (Onkologischer Basisdatensatz v3.0.5). Bildet die XML-Struktur einer einzelnen Meldung ab, wie sie von Meldestellen an die Krebsregister übermittelt wird."
    },
    {
      "id" : "obds-meldung.meldungID",
      "path" : "obds-meldung.meldungID",
      "short" : "Meldung_ID",
      "definition" : "Eindeutige Kennung der Meldung (XML-Attribut Meldung_ID)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.melderID",
      "path" : "obds-meldung.melderID",
      "short" : "Melder_ID",
      "definition" : "Kennung des Melders (XML-Attribut Melder_ID)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.meldebegruendung",
      "path" : "obds-meldung.meldebegruendung",
      "short" : "Meldebegruendung",
      "definition" : "Grund der Meldung: I=Behandlung, A=Diagnose, V=Verlauf, T=Tod",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.eigeneLeistung",
      "path" : "obds-meldung.eigeneLeistung",
      "short" : "Eigene Leistung",
      "definition" : "Ob die gemeldeten Daten auf eigener Leistung beruhen (J/N/U)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung",
      "path" : "obds-meldung.tumorzuordnung",
      "short" : "Tumorzuordnung",
      "definition" : "Zuordnung der Meldung zu einem bestimmten Tumor des Patienten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung.tumorID",
      "path" : "obds-meldung.tumorzuordnung.tumorID",
      "short" : "Tumor_ID",
      "definition" : "Eindeutige Kennung des Tumors (XML-Attribut Tumor_ID)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung.primaertumorICD",
      "path" : "obds-meldung.tumorzuordnung.primaertumorICD",
      "short" : "Primaertumor_ICD",
      "definition" : "ICD-10-GM-Kodierung des Primaertumors",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung.primaertumorICD.code",
      "path" : "obds-meldung.tumorzuordnung.primaertumorICD.code",
      "short" : "Code",
      "definition" : "ICD-10-GM Code (z.B. C50.4)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung.primaertumorICD.version",
      "path" : "obds-meldung.tumorzuordnung.primaertumorICD.version",
      "short" : "Version",
      "definition" : "ICD-10-GM Version (z.B. 10 2020 GM)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung.diagnosedatum",
      "path" : "obds-meldung.tumorzuordnung.diagnosedatum",
      "short" : "Diagnosedatum",
      "definition" : "Datum der Erstdiagnose des Tumors",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung.seitenlokalisation",
      "path" : "obds-meldung.tumorzuordnung.seitenlokalisation",
      "short" : "Seitenlokalisation",
      "definition" : "Seitenlokalisation: R=rechts, L=links, B=beidseitig, M=Mittellinie, T=trifft nicht zu, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung.morphologieICDO",
      "path" : "obds-meldung.tumorzuordnung.morphologieICDO",
      "short" : "Morphologie_ICD_O",
      "definition" : "ICD-O Morphologie-Kodierung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung.morphologieICDO.code",
      "path" : "obds-meldung.tumorzuordnung.morphologieICDO.code",
      "short" : "Code",
      "definition" : "ICD-O Morphologie-Code (z.B. 8500/3)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tumorzuordnung.morphologieICDO.version",
      "path" : "obds-meldung.tumorzuordnung.morphologieICDO.version",
      "short" : "Version",
      "definition" : "ICD-O Version (z.B. 31)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose",
      "path" : "obds-meldung.diagnose",
      "short" : "Diagnose",
      "definition" : "Diagnosemeldung mit klinischen Details zum Zeitpunkt der Erstdiagnose",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.primaertumorDiagnosetext",
      "path" : "obds-meldung.diagnose.primaertumorDiagnosetext",
      "short" : "Primaertumor_Diagnosetext",
      "definition" : "Freitextbeschreibung der Diagnose",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.primaertumorTopographieICDO",
      "path" : "obds-meldung.diagnose.primaertumorTopographieICDO",
      "short" : "Primaertumor_Topographie_ICD_O",
      "definition" : "ICD-O Topographie-Kodierung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.primaertumorTopographieICDO.code",
      "path" : "obds-meldung.diagnose.primaertumorTopographieICDO.code",
      "short" : "Code",
      "definition" : "ICD-O Topographie-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.primaertumorTopographieICDO.version",
      "path" : "obds-meldung.diagnose.primaertumorTopographieICDO.version",
      "short" : "Version",
      "definition" : "ICD-O Version",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.primaertumorTopographieFreitext",
      "path" : "obds-meldung.diagnose.primaertumorTopographieFreitext",
      "short" : "Primaertumor_Topographie_Freitext",
      "definition" : "Freitextbeschreibung der Topographie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.diagnosesicherung",
      "path" : "obds-meldung.diagnose.diagnosesicherung",
      "short" : "Diagnosesicherung",
      "definition" : "Hoechste erreichte Diagnosesicherheit: 1=klinisch, 2=klinisch mit Diagnostik, 4=Tumormarker, 5=zytologisch, 6=Histologie Metastase, 7=Histologie Primaertumor, 7.1-7.3=Histologie differenziert, 8=molekular, 9=unbekannt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.fruehereErkrankungen",
      "path" : "obds-meldung.diagnose.fruehereErkrankungen",
      "short" : "Fruehere_Tumorerkrankung",
      "definition" : "Fruehere Tumorerkrankungen in der Anamnese",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.fruehereErkrankungen.freitext",
      "path" : "obds-meldung.diagnose.fruehereErkrankungen.freitext",
      "short" : "Freitext",
      "definition" : "Freitextbeschreibung der frueheren Tumorerkrankung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.fruehereErkrankungen.icdCode",
      "path" : "obds-meldung.diagnose.fruehereErkrankungen.icdCode",
      "short" : "ICD Code",
      "definition" : "ICD-10-Code der frueheren Erkrankung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.fruehereErkrankungen.icdVersion",
      "path" : "obds-meldung.diagnose.fruehereErkrankungen.icdVersion",
      "short" : "ICD Version",
      "definition" : "Version des ICD-Codes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.fruehereErkrankungen.diagnosedatum",
      "path" : "obds-meldung.diagnose.fruehereErkrankungen.diagnosedatum",
      "short" : "Diagnosedatum",
      "definition" : "Jahr der frueheren Tumorerkrankung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie",
      "path" : "obds-meldung.diagnose.histologie",
      "short" : "Histologie",
      "definition" : "Histologiebefund zum Diagnosezeitpunkt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.histologieID",
      "path" : "obds-meldung.diagnose.histologie.histologieID",
      "short" : "Histologie_ID",
      "definition" : "Eindeutige Kennung des Histologiebefunds",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.tumorHistologiedatum",
      "path" : "obds-meldung.diagnose.histologie.tumorHistologiedatum",
      "short" : "Tumor_Histologiedatum",
      "definition" : "Datum des Histologiebefunds",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.histologieEinsendeNr",
      "path" : "obds-meldung.diagnose.histologie.histologieEinsendeNr",
      "short" : "Histologie_EinsendeNr",
      "definition" : "Einsende-Nummer des Histologiebefunds",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.morphologieICDO",
      "path" : "obds-meldung.diagnose.histologie.morphologieICDO",
      "short" : "Morphologie_ICD_O",
      "definition" : "ICD-O Morphologie-Kodierung",
      "min" : 0,
      "max" : "5",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.morphologieICDO.code",
      "path" : "obds-meldung.diagnose.histologie.morphologieICDO.code",
      "short" : "Code",
      "definition" : "ICD-O Morphologie-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.morphologieICDO.version",
      "path" : "obds-meldung.diagnose.histologie.morphologieICDO.version",
      "short" : "Version",
      "definition" : "ICD-O Version",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.morphologieFreitext",
      "path" : "obds-meldung.diagnose.histologie.morphologieFreitext",
      "short" : "Morphologie_Freitext",
      "definition" : "Freitextbeschreibung der Morphologie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.grading",
      "path" : "obds-meldung.diagnose.histologie.grading",
      "short" : "Grading",
      "definition" : "Histopathologisches Grading: 0-4, X, L, M, H, B, U, T",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.lkUntersucht",
      "path" : "obds-meldung.diagnose.histologie.lkUntersucht",
      "short" : "LK_untersucht",
      "definition" : "Anzahl untersuchter Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.lkBefallen",
      "path" : "obds-meldung.diagnose.histologie.lkBefallen",
      "short" : "LK_befallen",
      "definition" : "Anzahl befallener Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.sentinelLKUntersucht",
      "path" : "obds-meldung.diagnose.histologie.sentinelLKUntersucht",
      "short" : "Sentinel_LK_untersucht",
      "definition" : "Anzahl untersuchter Sentinel-Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.histologie.sentinelLKBefallen",
      "path" : "obds-meldung.diagnose.histologie.sentinelLKBefallen",
      "short" : "Sentinel_LK_befallen",
      "definition" : "Anzahl befallener Sentinel-Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.fernmetastasen",
      "path" : "obds-meldung.diagnose.fernmetastasen",
      "short" : "Fernmetastase",
      "definition" : "Fernmetastasen zum Diagnosezeitpunkt",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.fernmetastasen.diagnosedatum",
      "path" : "obds-meldung.diagnose.fernmetastasen.diagnosedatum",
      "short" : "Diagnosedatum",
      "definition" : "Datum der Fernmetastasen-Diagnose",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.fernmetastasen.lokalisation",
      "path" : "obds-meldung.diagnose.fernmetastasen.lokalisation",
      "short" : "Lokalisation",
      "definition" : "Lokalisation der Fernmetastase: PUL, OSS, HEP, BRA, LYM, MAR, PLE, PER, ADR, SKI, OTH, GEN",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM",
      "path" : "obds-meldung.diagnose.cTNM",
      "short" : "cTNM",
      "definition" : "Praeetherapeutisches klinisches TNM-Stadium",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.datum",
      "path" : "obds-meldung.diagnose.cTNM.datum",
      "short" : "Datum",
      "definition" : "Datum der TNM-Klassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.version",
      "path" : "obds-meldung.diagnose.cTNM.version",
      "short" : "Version",
      "definition" : "TNM-Auflage (6, 7, 8, 9)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.ySymbol",
      "path" : "obds-meldung.diagnose.cTNM.ySymbol",
      "short" : "y_Symbol",
      "definition" : "y-Symbol: Klassifikation nach multimodaler Therapie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.rSymbol",
      "path" : "obds-meldung.diagnose.cTNM.rSymbol",
      "short" : "r_Symbol",
      "definition" : "r-Symbol: Rezidivklassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.aSymbol",
      "path" : "obds-meldung.diagnose.cTNM.aSymbol",
      "short" : "a_Symbol",
      "definition" : "a-Symbol: Autopsie-Klassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.cpuPraefixT",
      "path" : "obds-meldung.diagnose.cTNM.cpuPraefixT",
      "short" : "c_p_u_Praefix_T",
      "definition" : "Praefix der T-Kategorie: c, p oder u",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.t",
      "path" : "obds-meldung.diagnose.cTNM.t",
      "short" : "T",
      "definition" : "T-Kategorie (Primaertumor)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.mSymbol",
      "path" : "obds-meldung.diagnose.cTNM.mSymbol",
      "short" : "m_Symbol",
      "definition" : "m-Symbol: multiple Primaertumoren",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.cpuPraefixN",
      "path" : "obds-meldung.diagnose.cTNM.cpuPraefixN",
      "short" : "c_p_u_Praefix_N",
      "definition" : "Praefix der N-Kategorie: c, p oder u",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.n",
      "path" : "obds-meldung.diagnose.cTNM.n",
      "short" : "N",
      "definition" : "N-Kategorie (regionaere Lymphknoten)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.cpuPraefixM",
      "path" : "obds-meldung.diagnose.cTNM.cpuPraefixM",
      "short" : "c_p_u_Praefix_M",
      "definition" : "Praefix der M-Kategorie: c, p oder u",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.m",
      "path" : "obds-meldung.diagnose.cTNM.m",
      "short" : "M",
      "definition" : "M-Kategorie (Fernmetastasen)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.l",
      "path" : "obds-meldung.diagnose.cTNM.l",
      "short" : "L",
      "definition" : "Lymphgefaessinvasion: L0, L1, LX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.v",
      "path" : "obds-meldung.diagnose.cTNM.v",
      "short" : "V",
      "definition" : "Veneninvasion: V0, V1, V2, VX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.pn",
      "path" : "obds-meldung.diagnose.cTNM.pn",
      "short" : "Pn",
      "definition" : "Perineurale Invasion: Pn0, Pn1, PnX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.s",
      "path" : "obds-meldung.diagnose.cTNM.s",
      "short" : "S",
      "definition" : "Serumtumormarker: S0, S1, S2, S3, SX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.cTNM.uiccStadium",
      "path" : "obds-meldung.diagnose.cTNM.uiccStadium",
      "short" : "UICC_Stadium",
      "definition" : "UICC-Stadium (z.B. IA, IIB, IIIA, IV)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM",
      "path" : "obds-meldung.diagnose.pTNM",
      "short" : "pTNM",
      "definition" : "Postoperatives pathologisches TNM-Stadium",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.datum",
      "path" : "obds-meldung.diagnose.pTNM.datum",
      "short" : "Datum",
      "definition" : "Datum der TNM-Klassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.version",
      "path" : "obds-meldung.diagnose.pTNM.version",
      "short" : "Version",
      "definition" : "TNM-Auflage (6, 7, 8, 9)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.ySymbol",
      "path" : "obds-meldung.diagnose.pTNM.ySymbol",
      "short" : "y_Symbol",
      "definition" : "y-Symbol: Klassifikation nach multimodaler Therapie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.rSymbol",
      "path" : "obds-meldung.diagnose.pTNM.rSymbol",
      "short" : "r_Symbol",
      "definition" : "r-Symbol: Rezidivklassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.aSymbol",
      "path" : "obds-meldung.diagnose.pTNM.aSymbol",
      "short" : "a_Symbol",
      "definition" : "a-Symbol: Autopsie-Klassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.cpuPraefixT",
      "path" : "obds-meldung.diagnose.pTNM.cpuPraefixT",
      "short" : "c_p_u_Praefix_T",
      "definition" : "Praefix der T-Kategorie: c, p oder u",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.t",
      "path" : "obds-meldung.diagnose.pTNM.t",
      "short" : "T",
      "definition" : "T-Kategorie (Primaertumor)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.mSymbol",
      "path" : "obds-meldung.diagnose.pTNM.mSymbol",
      "short" : "m_Symbol",
      "definition" : "m-Symbol: multiple Primaertumoren",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.cpuPraefixN",
      "path" : "obds-meldung.diagnose.pTNM.cpuPraefixN",
      "short" : "c_p_u_Praefix_N",
      "definition" : "Praefix der N-Kategorie: c, p oder u",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.n",
      "path" : "obds-meldung.diagnose.pTNM.n",
      "short" : "N",
      "definition" : "N-Kategorie (regionaere Lymphknoten)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.cpuPraefixM",
      "path" : "obds-meldung.diagnose.pTNM.cpuPraefixM",
      "short" : "c_p_u_Praefix_M",
      "definition" : "Praefix der M-Kategorie: c, p oder u",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.m",
      "path" : "obds-meldung.diagnose.pTNM.m",
      "short" : "M",
      "definition" : "M-Kategorie (Fernmetastasen)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.l",
      "path" : "obds-meldung.diagnose.pTNM.l",
      "short" : "L",
      "definition" : "Lymphgefaessinvasion: L0, L1, LX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.v",
      "path" : "obds-meldung.diagnose.pTNM.v",
      "short" : "V",
      "definition" : "Veneninvasion: V0, V1, V2, VX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.pn",
      "path" : "obds-meldung.diagnose.pTNM.pn",
      "short" : "Pn",
      "definition" : "Perineurale Invasion: Pn0, Pn1, PnX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.s",
      "path" : "obds-meldung.diagnose.pTNM.s",
      "short" : "S",
      "definition" : "Serumtumormarker: S0, S1, S2, S3, SX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.pTNM.uiccStadium",
      "path" : "obds-meldung.diagnose.pTNM.uiccStadium",
      "short" : "UICC_Stadium",
      "definition" : "UICC-Stadium (z.B. IA, IIB, IIIA, IV)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.allgemeinerLeistungszustand",
      "path" : "obds-meldung.diagnose.allgemeinerLeistungszustand",
      "short" : "Allgemeiner_Leistungszustand",
      "definition" : "ECOG-Leistungszustand: 0-4, U=unbekannt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.modulMamma",
      "path" : "obds-meldung.diagnose.modulMamma",
      "short" : "Modul_Mamma",
      "definition" : "Mammaspezifische Zusatzdaten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.modulMamma.praetherapeutischerMenopausenstatus",
      "path" : "obds-meldung.diagnose.modulMamma.praetherapeutischerMenopausenstatus",
      "short" : "Praetherapeutischer_Menopausenstatus",
      "definition" : "Menopausenstatus: 1=praemenopausal, 3=postmenopausal, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.modulMamma.hormonrezeptorStatusOestrogen",
      "path" : "obds-meldung.diagnose.modulMamma.hormonrezeptorStatusOestrogen",
      "short" : "HormonrezeptorStatus_Oestrogen",
      "definition" : "Oestrogenrezeptorstatus: P=positiv, N=negativ, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.modulMamma.hormonrezeptorStatusProgesteron",
      "path" : "obds-meldung.diagnose.modulMamma.hormonrezeptorStatusProgesteron",
      "short" : "HormonrezeptorStatus_Progesteron",
      "definition" : "Progesteronrezeptorstatus: P=positiv, N=negativ, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.modulMamma.her2neuStatus",
      "path" : "obds-meldung.diagnose.modulMamma.her2neuStatus",
      "short" : "Her2neuStatus",
      "definition" : "HER2-Rezeptorstatus: P=positiv, N=negativ, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.modulMamma.praeopDrahtmarkierung",
      "path" : "obds-meldung.diagnose.modulMamma.praeopDrahtmarkierung",
      "short" : "PraeopDrahtmarkierung",
      "definition" : "Praeoperative Drahtmarkierung: M=Mammografie, S=Sonografie, T=MRT, N=keine, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.modulMamma.intraopPraeparatkontrolle",
      "path" : "obds-meldung.diagnose.modulMamma.intraopPraeparatkontrolle",
      "short" : "IntraopPraeparatkontrolle",
      "definition" : "Intraoperative Praeparatkontrolle (QI-3): M=Mammografie, S=Sonografie, N=nein, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.modulMamma.tumorgroesseInvasiv",
      "path" : "obds-meldung.diagnose.modulMamma.tumorgroesseInvasiv",
      "short" : "TumorgroesseInvasiv",
      "definition" : "Groesse des invasiven Tumorherdes in mm (maximaler Durchmesser)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.modulMamma.tumorgroesseDCIS",
      "path" : "obds-meldung.diagnose.modulMamma.tumorgroesseDCIS",
      "short" : "TumorgroesseDCIS",
      "definition" : "Groesse der DCIS-Komponente in mm (maximaler Durchmesser)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.weitereKlassifikationen",
      "path" : "obds-meldung.diagnose.weitereKlassifikationen",
      "short" : "Menge_Weitere_Klassifikation",
      "definition" : "Weitere onkologische Klassifikationen (z.B. Genexpressionstests Oncotype DX, MammaPrint)",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.weitereKlassifikationen.datum",
      "path" : "obds-meldung.diagnose.weitereKlassifikationen.datum",
      "short" : "Datum",
      "definition" : "Datum der Klassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.weitereKlassifikationen.name",
      "path" : "obds-meldung.diagnose.weitereKlassifikationen.name",
      "short" : "Name",
      "definition" : "Name der Klassifikation (z.B. 'Oncotype DX', 'MammaPrint')",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.diagnose.weitereKlassifikationen.stadium",
      "path" : "obds-meldung.diagnose.weitereKlassifikationen.stadium",
      "short" : "Stadium",
      "definition" : "Ergebnis/Stadium der Klassifikation (z.B. 'RS 18 / low risk')",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op",
      "path" : "obds-meldung.op",
      "short" : "OP",
      "definition" : "Operationsmeldung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.opID",
      "path" : "obds-meldung.op.opID",
      "short" : "OP_ID",
      "definition" : "Eindeutige Kennung der Operation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.intention",
      "path" : "obds-meldung.op.intention",
      "short" : "Intention",
      "definition" : "Intention der OP: K=kurativ, P=palliativ, D=diagnostisch, R=Revision, S=Sonstiges, X=fehlend",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.datum",
      "path" : "obds-meldung.op.datum",
      "short" : "Datum",
      "definition" : "Datum der Operation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.op.opsKodes",
      "path" : "obds-meldung.op.opsKodes",
      "short" : "OPS",
      "definition" : "OPS-Prozedurenkodes",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.opsKodes.code",
      "path" : "obds-meldung.op.opsKodes.code",
      "short" : "Code",
      "definition" : "OPS-Code (z.B. 5-870.a2)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.opsKodes.version",
      "path" : "obds-meldung.op.opsKodes.version",
      "short" : "Version",
      "definition" : "OPS-Version (z.B. 2020)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie",
      "path" : "obds-meldung.op.histologie",
      "short" : "Histologie",
      "definition" : "Histologiebefund der OP",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.histologieID",
      "path" : "obds-meldung.op.histologie.histologieID",
      "short" : "Histologie_ID",
      "definition" : "Eindeutige Kennung des Histologiebefunds",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.tumorHistologiedatum",
      "path" : "obds-meldung.op.histologie.tumorHistologiedatum",
      "short" : "Tumor_Histologiedatum",
      "definition" : "Datum des Histologiebefunds",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.histologieEinsendeNr",
      "path" : "obds-meldung.op.histologie.histologieEinsendeNr",
      "short" : "Histologie_EinsendeNr",
      "definition" : "Einsende-Nummer des Histologiebefunds",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.morphologieICDO",
      "path" : "obds-meldung.op.histologie.morphologieICDO",
      "short" : "Morphologie_ICD_O",
      "definition" : "ICD-O Morphologie-Kodierung",
      "min" : 0,
      "max" : "5",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.morphologieICDO.code",
      "path" : "obds-meldung.op.histologie.morphologieICDO.code",
      "short" : "Code",
      "definition" : "ICD-O Morphologie-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.morphologieICDO.version",
      "path" : "obds-meldung.op.histologie.morphologieICDO.version",
      "short" : "Version",
      "definition" : "ICD-O Version",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.morphologieFreitext",
      "path" : "obds-meldung.op.histologie.morphologieFreitext",
      "short" : "Morphologie_Freitext",
      "definition" : "Freitextbeschreibung der Morphologie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.grading",
      "path" : "obds-meldung.op.histologie.grading",
      "short" : "Grading",
      "definition" : "Histopathologisches Grading: 0-4, X, L, M, H, B, U, T",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.lkUntersucht",
      "path" : "obds-meldung.op.histologie.lkUntersucht",
      "short" : "LK_untersucht",
      "definition" : "Anzahl untersuchter Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.lkBefallen",
      "path" : "obds-meldung.op.histologie.lkBefallen",
      "short" : "LK_befallen",
      "definition" : "Anzahl befallener Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.sentinelLKUntersucht",
      "path" : "obds-meldung.op.histologie.sentinelLKUntersucht",
      "short" : "Sentinel_LK_untersucht",
      "definition" : "Anzahl untersuchter Sentinel-Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.op.histologie.sentinelLKBefallen",
      "path" : "obds-meldung.op.histologie.sentinelLKBefallen",
      "short" : "Sentinel_LK_befallen",
      "definition" : "Anzahl befallener Sentinel-Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm",
      "path" : "obds-meldung.op.tnm",
      "short" : "TNM",
      "definition" : "Postoperatives TNM-Stadium",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.datum",
      "path" : "obds-meldung.op.tnm.datum",
      "short" : "Datum",
      "definition" : "Datum der TNM-Klassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.version",
      "path" : "obds-meldung.op.tnm.version",
      "short" : "Version",
      "definition" : "TNM-Auflage (6, 7, 8, 9)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.ySymbol",
      "path" : "obds-meldung.op.tnm.ySymbol",
      "short" : "y_Symbol",
      "definition" : "y-Symbol: Klassifikation nach multimodaler Therapie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.rSymbol",
      "path" : "obds-meldung.op.tnm.rSymbol",
      "short" : "r_Symbol",
      "definition" : "r-Symbol: Rezidivklassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.aSymbol",
      "path" : "obds-meldung.op.tnm.aSymbol",
      "short" : "a_Symbol",
      "definition" : "a-Symbol: Autopsie-Klassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.cpuPraefixT",
      "path" : "obds-meldung.op.tnm.cpuPraefixT",
      "short" : "c_p_u_Praefix_T",
      "definition" : "Praefix der T-Kategorie: c, p oder u",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.t",
      "path" : "obds-meldung.op.tnm.t",
      "short" : "T",
      "definition" : "T-Kategorie (Primaertumor)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.mSymbol",
      "path" : "obds-meldung.op.tnm.mSymbol",
      "short" : "m_Symbol",
      "definition" : "m-Symbol: multiple Primaertumoren",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.cpuPraefixN",
      "path" : "obds-meldung.op.tnm.cpuPraefixN",
      "short" : "c_p_u_Praefix_N",
      "definition" : "Praefix der N-Kategorie: c, p oder u",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.n",
      "path" : "obds-meldung.op.tnm.n",
      "short" : "N",
      "definition" : "N-Kategorie (regionaere Lymphknoten)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.cpuPraefixM",
      "path" : "obds-meldung.op.tnm.cpuPraefixM",
      "short" : "c_p_u_Praefix_M",
      "definition" : "Praefix der M-Kategorie: c, p oder u",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.m",
      "path" : "obds-meldung.op.tnm.m",
      "short" : "M",
      "definition" : "M-Kategorie (Fernmetastasen)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.l",
      "path" : "obds-meldung.op.tnm.l",
      "short" : "L",
      "definition" : "Lymphgefaessinvasion: L0, L1, LX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.v",
      "path" : "obds-meldung.op.tnm.v",
      "short" : "V",
      "definition" : "Veneninvasion: V0, V1, V2, VX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.pn",
      "path" : "obds-meldung.op.tnm.pn",
      "short" : "Pn",
      "definition" : "Perineurale Invasion: Pn0, Pn1, PnX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.s",
      "path" : "obds-meldung.op.tnm.s",
      "short" : "S",
      "definition" : "Serumtumormarker: S0, S1, S2, S3, SX",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.tnm.uiccStadium",
      "path" : "obds-meldung.op.tnm.uiccStadium",
      "short" : "UICC_Stadium",
      "definition" : "UICC-Stadium (z.B. IA, IIB, IIIA, IV)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.residualstatus",
      "path" : "obds-meldung.op.residualstatus",
      "short" : "Residualstatus",
      "definition" : "Residualtumorstatus nach OP",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.residualstatus.lokaleBeurteilung",
      "path" : "obds-meldung.op.residualstatus.lokaleBeurteilung",
      "short" : "Lokale_Beurteilung_Residualstatus",
      "definition" : "Lokaler Residualstatus: R0, R1, R1(is), R1(cy+), R2, RX, U",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.residualstatus.gesamtbeurteilung",
      "path" : "obds-meldung.op.residualstatus.gesamtbeurteilung",
      "short" : "Gesamtbeurteilung_Residualstatus",
      "definition" : "Gesamtbeurteilung Residualstatus: R0, R1, R1(is), R1(cy+), R2, RX, U",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.komplikationen",
      "path" : "obds-meldung.op.komplikationen",
      "short" : "Komplikationen",
      "definition" : "Operative Komplikationen",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.komplikationen.komplikationNeinOderUnbekannt",
      "path" : "obds-meldung.op.komplikationen.komplikationNeinOderUnbekannt",
      "short" : "Komplikation_nein_oder_unbekannt",
      "definition" : "N=keine Komplikation, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.komplikationen.komplikation",
      "path" : "obds-meldung.op.komplikationen.komplikation",
      "short" : "Komplikation",
      "definition" : "Aufgetretene Komplikation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.komplikationen.komplikation.kuerzel",
      "path" : "obds-meldung.op.komplikationen.komplikation.kuerzel",
      "short" : "Kuerzel",
      "definition" : "Komplikationskuerzel (z.B. ABD, ABS, ASF, WUH)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.komplikationen.komplikation.icd",
      "path" : "obds-meldung.op.komplikationen.komplikation.icd",
      "short" : "ICD",
      "definition" : "ICD-Kodierung der Komplikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.komplikationen.komplikation.icd.code",
      "path" : "obds-meldung.op.komplikationen.komplikation.icd.code",
      "short" : "Code",
      "definition" : "ICD-10-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.komplikationen.komplikation.icd.version",
      "path" : "obds-meldung.op.komplikationen.komplikation.icd.version",
      "short" : "Version",
      "definition" : "ICD-10-Version",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.operateure",
      "path" : "obds-meldung.op.operateure",
      "short" : "Operateur",
      "definition" : "Beteiligte Operateure",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.operateure.nachname",
      "path" : "obds-meldung.op.operateure.nachname",
      "short" : "Nachname",
      "definition" : "Nachname des Operateurs",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.operateure.vornamen",
      "path" : "obds-meldung.op.operateure.vornamen",
      "short" : "Vornamen",
      "definition" : "Vornamen des Operateurs",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.op.operateure.hauptoperateur",
      "path" : "obds-meldung.op.operateure.hauptoperateur",
      "short" : "Hauptoperateur",
      "definition" : "Ob Hauptoperateur: J/N",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.modulMamma",
      "path" : "obds-meldung.op.modulMamma",
      "short" : "Modul_Mamma",
      "definition" : "Mammaspezifische Zusatzdaten zur OP",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.op.modulMamma.praetherapeutischerMenopausenstatus",
      "path" : "obds-meldung.op.modulMamma.praetherapeutischerMenopausenstatus",
      "short" : "Praetherapeutischer_Menopausenstatus",
      "definition" : "Menopausenstatus: 1=praemenopausal, 3=postmenopausal, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.modulMamma.hormonrezeptorStatusOestrogen",
      "path" : "obds-meldung.op.modulMamma.hormonrezeptorStatusOestrogen",
      "short" : "HormonrezeptorStatus_Oestrogen",
      "definition" : "Oestrogenrezeptorstatus: P=positiv, N=negativ, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.modulMamma.hormonrezeptorStatusProgesteron",
      "path" : "obds-meldung.op.modulMamma.hormonrezeptorStatusProgesteron",
      "short" : "HormonrezeptorStatus_Progesteron",
      "definition" : "Progesteronrezeptorstatus: P=positiv, N=negativ, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.modulMamma.her2neuStatus",
      "path" : "obds-meldung.op.modulMamma.her2neuStatus",
      "short" : "Her2neuStatus",
      "definition" : "HER2-Rezeptorstatus: P=positiv, N=negativ, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.modulMamma.praeopDrahtmarkierung",
      "path" : "obds-meldung.op.modulMamma.praeopDrahtmarkierung",
      "short" : "PraeopDrahtmarkierung",
      "definition" : "Praeoperative Drahtmarkierung: M=Mammografie, S=Sonografie, T=MRT, N=keine, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.modulMamma.intraopPraeparatkontrolle",
      "path" : "obds-meldung.op.modulMamma.intraopPraeparatkontrolle",
      "short" : "IntraopPraeparatkontrolle",
      "definition" : "Intraoperative Praeparatkontrolle (QI-3): M=Mammografie, S=Sonografie, N=nein, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.op.modulMamma.tumorgroesseInvasiv",
      "path" : "obds-meldung.op.modulMamma.tumorgroesseInvasiv",
      "short" : "TumorgroesseInvasiv",
      "definition" : "Groesse des invasiven Tumorherdes in mm (maximaler Durchmesser)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.op.modulMamma.tumorgroesseDCIS",
      "path" : "obds-meldung.op.modulMamma.tumorgroesseDCIS",
      "short" : "TumorgroesseDCIS",
      "definition" : "Groesse der DCIS-Komponente in mm (maximaler Durchmesser)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.syst",
      "path" : "obds-meldung.syst",
      "short" : "SYST",
      "definition" : "Systemische Therapiemeldung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.syst.systID",
      "path" : "obds-meldung.syst.systID",
      "short" : "SYST_ID",
      "definition" : "Eindeutige Kennung der systemischen Therapie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.syst.meldeanlass",
      "path" : "obds-meldung.syst.meldeanlass",
      "short" : "Meldeanlass",
      "definition" : "Meldeanlass: behandlungsbeginn, behandlungsende",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.syst.intention",
      "path" : "obds-meldung.syst.intention",
      "short" : "Intention",
      "definition" : "Intention der Therapie: K=kurativ, P=palliativ, S=Sonstiges, X=fehlend",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.syst.stellungOP",
      "path" : "obds-meldung.syst.stellungOP",
      "short" : "Stellung_OP",
      "definition" : "Stellung zur OP: O=ohne Bezug, A=adjuvant, N=neoadjuvant, I=intraoperativ, S=Sonstiges",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.syst.therapieart",
      "path" : "obds-meldung.syst.therapieart",
      "short" : "Therapieart",
      "definition" : "Art der Therapie: CH, HO, IM, ZS, CI, CZ, CIZ, IZ, SZ, AS, WS, WW, SO",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.syst.protokoll",
      "path" : "obds-meldung.syst.protokoll",
      "short" : "Protokoll",
      "definition" : "Therapieprotokoll / Bezeichnung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.syst.beginn",
      "path" : "obds-meldung.syst.beginn",
      "short" : "Beginn",
      "definition" : "Startdatum der Therapie",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "obds-meldung.syst.ende",
      "path" : "obds-meldung.syst.ende",
      "short" : "Ende",
      "definition" : "Enddatum der Therapie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.syst.endeGrund",
      "path" : "obds-meldung.syst.endeGrund",
      "short" : "Ende_Grund",
      "definition" : "Grund des Therapieendes: E=regulaer, R=Dosisreduktion, W=Substanzwechsel, A=Abbruch Nebenwirkung, P=Abbruch Progress, S=sonstig, V=Patient verweigert, T=verstorben, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.syst.substanzen",
      "path" : "obds-meldung.syst.substanzen",
      "short" : "Substanz",
      "definition" : "Verabreichte Substanzen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.syst.substanzen.bezeichnung",
      "path" : "obds-meldung.syst.substanzen.bezeichnung",
      "short" : "Bezeichnung",
      "definition" : "Freitextbezeichnung der Substanz",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.syst.substanzen.atcCode",
      "path" : "obds-meldung.syst.substanzen.atcCode",
      "short" : "ATC Code",
      "definition" : "ATC-Code der Substanz",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.syst.substanzen.atcVersion",
      "path" : "obds-meldung.syst.substanzen.atcVersion",
      "short" : "ATC Version",
      "definition" : "ATC-Version",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.syst.nebenwirkungen",
      "path" : "obds-meldung.syst.nebenwirkungen",
      "short" : "Nebenwirkungen",
      "definition" : "Nebenwirkungen der Therapie",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.syst.nebenwirkungen.gradMaximal2OderUnbekannt",
      "path" : "obds-meldung.syst.nebenwirkungen.gradMaximal2OderUnbekannt",
      "short" : "Grad_maximal2_oder_unbekannt",
      "definition" : "Maximaler Schweregrad <=2 oder unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.syst.nebenwirkungen.nebenwirkung",
      "path" : "obds-meldung.syst.nebenwirkungen.nebenwirkung",
      "short" : "Nebenwirkung",
      "definition" : "Einzelne Nebenwirkung Grad >=3",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.syst.nebenwirkungen.nebenwirkung.artBezeichnung",
      "path" : "obds-meldung.syst.nebenwirkungen.nebenwirkung.artBezeichnung",
      "short" : "Art Bezeichnung",
      "definition" : "Bezeichnung der Nebenwirkung (Freitext)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.syst.nebenwirkungen.nebenwirkung.artMedDRACode",
      "path" : "obds-meldung.syst.nebenwirkungen.nebenwirkung.artMedDRACode",
      "short" : "Art MedDRA Code",
      "definition" : "MedDRA-Code der Nebenwirkung (8-stellig)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.syst.nebenwirkungen.nebenwirkung.grad",
      "path" : "obds-meldung.syst.nebenwirkungen.nebenwirkung.grad",
      "short" : "Grad",
      "definition" : "CTCAE-Grad der Nebenwirkung (3, 4, 5)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.syst.nebenwirkungen.nebenwirkung.version",
      "path" : "obds-meldung.syst.nebenwirkungen.nebenwirkung.version",
      "short" : "Version",
      "definition" : "CTCAE-Version",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.st",
      "path" : "obds-meldung.st",
      "short" : "ST",
      "definition" : "Strahlentherapiemeldung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.st.stID",
      "path" : "obds-meldung.st.stID",
      "short" : "ST_ID",
      "definition" : "Eindeutige Kennung der Strahlentherapie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.st.meldeanlass",
      "path" : "obds-meldung.st.meldeanlass",
      "short" : "Meldeanlass",
      "definition" : "Meldeanlass: behandlungsbeginn, behandlungsende",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.intention",
      "path" : "obds-meldung.st.intention",
      "short" : "Intention",
      "definition" : "Intention: K=kurativ, P=palliativ, O=lokal kurativ bei Oligometastasierung, S=Sonstiges, X=fehlend",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.stellungOP",
      "path" : "obds-meldung.st.stellungOP",
      "short" : "Stellung_OP",
      "definition" : "Stellung zur OP: O=ohne Bezug, A=adjuvant, N=neoadjuvant, I=intraoperativ, Z=additiv, S=Sonstiges",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen",
      "path" : "obds-meldung.st.bestrahlungen",
      "short" : "Bestrahlung",
      "definition" : "Einzelne Bestrahlungsserien",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.beginn",
      "path" : "obds-meldung.st.bestrahlungen.beginn",
      "short" : "Beginn",
      "definition" : "Startdatum der Bestrahlung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.ende",
      "path" : "obds-meldung.st.bestrahlungen.ende",
      "short" : "Ende",
      "definition" : "Enddatum der Bestrahlung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.applikationsart",
      "path" : "obds-meldung.st.bestrahlungen.applikationsart",
      "short" : "Applikationsart",
      "definition" : "Art der Applikation: Perkutan oder Kontakt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.zielgebiet",
      "path" : "obds-meldung.st.bestrahlungen.zielgebiet",
      "short" : "Zielgebiet",
      "definition" : "Zielgebiet der Bestrahlung (CodeVersion)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.seiteZielgebiet",
      "path" : "obds-meldung.st.bestrahlungen.seiteZielgebiet",
      "short" : "Seite_Zielgebiet",
      "definition" : "Seitenlokalisation des Zielgebiets: L, R, B, M, T, U",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.gesamtdosis",
      "path" : "obds-meldung.st.bestrahlungen.gesamtdosis",
      "short" : "Gesamtdosis",
      "definition" : "Gesamtdosis in Gy oder MBq",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.gesamtdosisEinheit",
      "path" : "obds-meldung.st.bestrahlungen.gesamtdosisEinheit",
      "short" : "Gesamtdosis_Einheit",
      "definition" : "Einheit der Gesamtdosis: Gy oder MBq",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.einzeldosis",
      "path" : "obds-meldung.st.bestrahlungen.einzeldosis",
      "short" : "Einzeldosis",
      "definition" : "Einzeldosis in Gy oder MBq",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.einzeldosisEinheit",
      "path" : "obds-meldung.st.bestrahlungen.einzeldosisEinheit",
      "short" : "Einzeldosis_Einheit",
      "definition" : "Einheit der Einzeldosis: Gy oder MBq",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.bestrahlungen.boost",
      "path" : "obds-meldung.st.bestrahlungen.boost",
      "short" : "Boost",
      "definition" : "Boost-Bestrahlung: J=ja, N=nein, SIB=simultan integrierter Boost",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.endeGrund",
      "path" : "obds-meldung.st.endeGrund",
      "short" : "Ende_Grund",
      "definition" : "Grund des Therapieendes: E=regulaer, A=Abbruch Nebenwirkung, P=Abbruch Progress, S=sonstig, V=Patient verweigert, T=verstorben, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.nebenwirkungen",
      "path" : "obds-meldung.st.nebenwirkungen",
      "short" : "Nebenwirkungen",
      "definition" : "Nebenwirkungen der Strahlentherapie",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.st.nebenwirkungen.gradMaximal2OderUnbekannt",
      "path" : "obds-meldung.st.nebenwirkungen.gradMaximal2OderUnbekannt",
      "short" : "Grad_maximal2_oder_unbekannt",
      "definition" : "Maximaler Schweregrad <=2 oder unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.nebenwirkungen.nebenwirkung",
      "path" : "obds-meldung.st.nebenwirkungen.nebenwirkung",
      "short" : "Nebenwirkung",
      "definition" : "Einzelne Nebenwirkung Grad >=3",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.st.nebenwirkungen.nebenwirkung.artBezeichnung",
      "path" : "obds-meldung.st.nebenwirkungen.nebenwirkung.artBezeichnung",
      "short" : "Art Bezeichnung",
      "definition" : "Bezeichnung der Nebenwirkung (Freitext)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.st.nebenwirkungen.nebenwirkung.artMedDRACode",
      "path" : "obds-meldung.st.nebenwirkungen.nebenwirkung.artMedDRACode",
      "short" : "Art MedDRA Code",
      "definition" : "MedDRA-Code der Nebenwirkung (8-stellig)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.nebenwirkungen.nebenwirkung.grad",
      "path" : "obds-meldung.st.nebenwirkungen.nebenwirkung.grad",
      "short" : "Grad",
      "definition" : "CTCAE-Grad der Nebenwirkung (3, 4, 5)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.st.nebenwirkungen.nebenwirkung.version",
      "path" : "obds-meldung.st.nebenwirkungen.nebenwirkung.version",
      "short" : "Version",
      "definition" : "CTCAE-Version",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf",
      "path" : "obds-meldung.verlauf",
      "short" : "Verlauf",
      "definition" : "Verlaufsmeldung mit Tumorstatus",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.verlaufID",
      "path" : "obds-meldung.verlauf.verlaufID",
      "short" : "Verlauf_ID",
      "definition" : "Eindeutige Kennung des Verlaufs",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.meldeanlass",
      "path" : "obds-meldung.verlauf.meldeanlass",
      "short" : "Meldeanlass",
      "definition" : "Meldeanlass: statusaenderung, statusmeldung",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.untersuchungsdatum",
      "path" : "obds-meldung.verlauf.untersuchungsdatum",
      "short" : "Untersuchungsdatum_Verlauf",
      "definition" : "Datum der Verlaufsuntersuchung",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.gesamtbeurteilungTumorstatus",
      "path" : "obds-meldung.verlauf.gesamtbeurteilungTumorstatus",
      "short" : "Gesamtbeurteilung_Tumorstatus",
      "definition" : "Gesamtbeurteilung: V=Vollremission, T=Teilremission, K=keine Aenderung, P=Progression, D=divergent, B=Besserung, R=Vollremission mit Residuen, Y=Rezidiv, U=unmoeglich, X=fehlend",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.verlaufLokalerTumorstatus",
      "path" : "obds-meldung.verlauf.verlaufLokalerTumorstatus",
      "short" : "Verlauf_Lokaler_Tumorstatus",
      "definition" : "Lokaler Tumorstatus: K=kein Tumor, T=Tumorreste, P=Progress, N=No Change, R=Lokalrezidiv, F=fraglich, U=unbekannt, X=fehlend",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.verlaufTumorstatusLymphknoten",
      "path" : "obds-meldung.verlauf.verlaufTumorstatusLymphknoten",
      "short" : "Verlauf_Tumorstatus_Lymphknoten",
      "definition" : "LK-Tumorstatus: K, T, P, N, R, F, U, X",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.verlaufTumorstatusFernmetastasen",
      "path" : "obds-meldung.verlauf.verlaufTumorstatusFernmetastasen",
      "short" : "Verlauf_Tumorstatus_Fernmetastasen",
      "definition" : "FM-Tumorstatus: K, T, P, N, R, F, U, X",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.fernmetastasen",
      "path" : "obds-meldung.verlauf.fernmetastasen",
      "short" : "Fernmetastase",
      "definition" : "Neu diagnostizierte Fernmetastasen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.fernmetastasen.diagnosedatum",
      "path" : "obds-meldung.verlauf.fernmetastasen.diagnosedatum",
      "short" : "Diagnosedatum",
      "definition" : "Datum der Fernmetastasen-Diagnose",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.fernmetastasen.lokalisation",
      "path" : "obds-meldung.verlauf.fernmetastasen.lokalisation",
      "short" : "Lokalisation",
      "definition" : "Lokalisation: PUL, OSS, HEP, BRA, LYM, MAR, PLE, PER, ADR, SKI, OTH, GEN",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie",
      "path" : "obds-meldung.verlauf.histologie",
      "short" : "Histologie",
      "definition" : "Histologiebefund im Verlauf",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.histologieID",
      "path" : "obds-meldung.verlauf.histologie.histologieID",
      "short" : "Histologie_ID",
      "definition" : "Eindeutige Kennung des Histologiebefunds",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.tumorHistologiedatum",
      "path" : "obds-meldung.verlauf.histologie.tumorHistologiedatum",
      "short" : "Tumor_Histologiedatum",
      "definition" : "Datum des Histologiebefunds",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.histologieEinsendeNr",
      "path" : "obds-meldung.verlauf.histologie.histologieEinsendeNr",
      "short" : "Histologie_EinsendeNr",
      "definition" : "Einsende-Nummer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.morphologieICDO",
      "path" : "obds-meldung.verlauf.histologie.morphologieICDO",
      "short" : "Morphologie_ICD_O",
      "definition" : "ICD-O Morphologie-Kodierung",
      "min" : 0,
      "max" : "5",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.morphologieICDO.code",
      "path" : "obds-meldung.verlauf.histologie.morphologieICDO.code",
      "short" : "Code",
      "definition" : "ICD-O Morphologie-Code",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.morphologieICDO.version",
      "path" : "obds-meldung.verlauf.histologie.morphologieICDO.version",
      "short" : "Version",
      "definition" : "ICD-O Version",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.morphologieFreitext",
      "path" : "obds-meldung.verlauf.histologie.morphologieFreitext",
      "short" : "Morphologie_Freitext",
      "definition" : "Freitextbeschreibung der Morphologie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.grading",
      "path" : "obds-meldung.verlauf.histologie.grading",
      "short" : "Grading",
      "definition" : "Histopathologisches Grading: 0-4, X, L, M, H, B, U, T",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.lkUntersucht",
      "path" : "obds-meldung.verlauf.histologie.lkUntersucht",
      "short" : "LK_untersucht",
      "definition" : "Anzahl untersuchter Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.lkBefallen",
      "path" : "obds-meldung.verlauf.histologie.lkBefallen",
      "short" : "LK_befallen",
      "definition" : "Anzahl befallener Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.sentinelLKUntersucht",
      "path" : "obds-meldung.verlauf.histologie.sentinelLKUntersucht",
      "short" : "Sentinel_LK_untersucht",
      "definition" : "Anzahl untersuchter Sentinel-Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.histologie.sentinelLKBefallen",
      "path" : "obds-meldung.verlauf.histologie.sentinelLKBefallen",
      "short" : "Sentinel_LK_befallen",
      "definition" : "Anzahl befallener Sentinel-Lymphknoten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm",
      "path" : "obds-meldung.verlauf.tnm",
      "short" : "TNM",
      "definition" : "TNM-Stadium im Verlauf",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.datum",
      "path" : "obds-meldung.verlauf.tnm.datum",
      "short" : "Datum",
      "definition" : "Datum der TNM-Klassifikation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.version",
      "path" : "obds-meldung.verlauf.tnm.version",
      "short" : "Version",
      "definition" : "TNM-Auflage (6, 7, 8, 9)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.ySymbol",
      "path" : "obds-meldung.verlauf.tnm.ySymbol",
      "short" : "y_Symbol",
      "definition" : "y-Symbol",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.rSymbol",
      "path" : "obds-meldung.verlauf.tnm.rSymbol",
      "short" : "r_Symbol",
      "definition" : "r-Symbol",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.aSymbol",
      "path" : "obds-meldung.verlauf.tnm.aSymbol",
      "short" : "a_Symbol",
      "definition" : "a-Symbol",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.cpuPraefixT",
      "path" : "obds-meldung.verlauf.tnm.cpuPraefixT",
      "short" : "c_p_u_Praefix_T",
      "definition" : "Praefix der T-Kategorie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.t",
      "path" : "obds-meldung.verlauf.tnm.t",
      "short" : "T",
      "definition" : "T-Kategorie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.mSymbol",
      "path" : "obds-meldung.verlauf.tnm.mSymbol",
      "short" : "m_Symbol",
      "definition" : "m-Symbol",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.cpuPraefixN",
      "path" : "obds-meldung.verlauf.tnm.cpuPraefixN",
      "short" : "c_p_u_Praefix_N",
      "definition" : "Praefix der N-Kategorie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.n",
      "path" : "obds-meldung.verlauf.tnm.n",
      "short" : "N",
      "definition" : "N-Kategorie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.cpuPraefixM",
      "path" : "obds-meldung.verlauf.tnm.cpuPraefixM",
      "short" : "c_p_u_Praefix_M",
      "definition" : "Praefix der M-Kategorie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.m",
      "path" : "obds-meldung.verlauf.tnm.m",
      "short" : "M",
      "definition" : "M-Kategorie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.l",
      "path" : "obds-meldung.verlauf.tnm.l",
      "short" : "L",
      "definition" : "Lymphgefaessinvasion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.v",
      "path" : "obds-meldung.verlauf.tnm.v",
      "short" : "V",
      "definition" : "Veneninvasion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.pn",
      "path" : "obds-meldung.verlauf.tnm.pn",
      "short" : "Pn",
      "definition" : "Perineurale Invasion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.s",
      "path" : "obds-meldung.verlauf.tnm.s",
      "short" : "S",
      "definition" : "Serumtumormarker",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.tnm.uiccStadium",
      "path" : "obds-meldung.verlauf.tnm.uiccStadium",
      "short" : "UICC_Stadium",
      "definition" : "UICC-Stadium",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.allgemeinerLeistungszustand",
      "path" : "obds-meldung.verlauf.allgemeinerLeistungszustand",
      "short" : "Allgemeiner_Leistungszustand",
      "definition" : "ECOG-Leistungszustand: 0-4, U=unbekannt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.modulMamma",
      "path" : "obds-meldung.verlauf.modulMamma",
      "short" : "Modul_Mamma",
      "definition" : "Mammaspezifische Zusatzdaten zum Verlauf",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.modulMamma.hormonrezeptorStatusOestrogen",
      "path" : "obds-meldung.verlauf.modulMamma.hormonrezeptorStatusOestrogen",
      "short" : "HormonrezeptorStatus_Oestrogen",
      "definition" : "Oestrogenrezeptorstatus: P=positiv, N=negativ, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.modulMamma.hormonrezeptorStatusProgesteron",
      "path" : "obds-meldung.verlauf.modulMamma.hormonrezeptorStatusProgesteron",
      "short" : "HormonrezeptorStatus_Progesteron",
      "definition" : "Progesteronrezeptorstatus: P=positiv, N=negativ, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.verlauf.modulMamma.her2neuStatus",
      "path" : "obds-meldung.verlauf.modulMamma.her2neuStatus",
      "short" : "Her2neuStatus",
      "definition" : "HER2-Rezeptorstatus: P=positiv, N=negativ, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tumorkonferenz",
      "path" : "obds-meldung.tumorkonferenz",
      "short" : "Tumorkonferenz",
      "definition" : "Tumorkonferenzmeldung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.tumorkonferenz.tumorkonferenzID",
      "path" : "obds-meldung.tumorkonferenz.tumorkonferenzID",
      "short" : "Tumorkonferenz_ID",
      "definition" : "Eindeutige Kennung der Tumorkonferenz",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.tumorkonferenz.meldeanlass",
      "path" : "obds-meldung.tumorkonferenz.meldeanlass",
      "short" : "Meldeanlass",
      "definition" : "Meldeanlass: diagnose, behandlungsbeginn, behandlungsende, statusaenderung",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tumorkonferenz.datum",
      "path" : "obds-meldung.tumorkonferenz.datum",
      "short" : "Datum",
      "definition" : "Datum der Tumorkonferenz",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "obds-meldung.tumorkonferenz.typ",
      "path" : "obds-meldung.tumorkonferenz.typ",
      "short" : "Typ",
      "definition" : "Art der Konferenz: praeth=praetherapeutisch, postop=postoperativ, postth=posttherapeutisch, ther=Therapieplanung ohne Konferenz",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tumorkonferenz.therapieempfehlung",
      "path" : "obds-meldung.tumorkonferenz.therapieempfehlung",
      "short" : "Therapieempfehlung",
      "definition" : "Empfohlene Therapien",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.tumorkonferenz.therapieempfehlung.typTherapieempfehlung",
      "path" : "obds-meldung.tumorkonferenz.therapieempfehlung.typTherapieempfehlung",
      "short" : "Typ_Therapieempfehlung",
      "definition" : "Empfohlene Therapieart: OP, ST, CH, HO, IM, ZS, CI, CZ, CIZ, IZ, SZ, AS, WS, WW, SO, KS",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tumorkonferenz.therapieempfehlung.abweichungPatientenwunsch",
      "path" : "obds-meldung.tumorkonferenz.therapieempfehlung.abweichungPatientenwunsch",
      "short" : "Abweichung_Patientenwunsch",
      "definition" : "Abweichung vom Patientenwunsch: J=ja, N=nein, U=unbekannt",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tod",
      "path" : "obds-meldung.tod",
      "short" : "Tod",
      "definition" : "Todesmeldung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.tod.abschlussID",
      "path" : "obds-meldung.tod.abschlussID",
      "short" : "Abschluss_ID",
      "definition" : "Eindeutige Kennung der Todesmeldung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "obds-meldung.tod.sterbedatum",
      "path" : "obds-meldung.tod.sterbedatum",
      "short" : "Sterbedatum",
      "definition" : "Sterbedatum des Patienten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "obds-meldung.tod.todTumorbedingt",
      "path" : "obds-meldung.tod.todTumorbedingt",
      "short" : "Tod_tumorbedingt",
      "definition" : "Ob der Tod tumorbedingt war: J=ja, N=nein, U=unbekannt",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tod.todesursachen",
      "path" : "obds-meldung.tod.todesursachen",
      "short" : "Todesursache_ICD",
      "definition" : "ICD-kodierte Todesursachen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "obds-meldung.tod.todesursachen.code",
      "path" : "obds-meldung.tod.todesursachen.code",
      "short" : "Code",
      "definition" : "ICD-10-Code der Todesursache",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "obds-meldung.tod.todesursachen.version",
      "path" : "obds-meldung.tod.todesursachen.version",
      "short" : "Version",
      "definition" : "ICD-10-Version",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
