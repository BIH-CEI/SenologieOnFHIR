# Home - Kerndatensatz Senologie v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.senologie.org/fhir/ImplementationGuide/kds-senologie | *Version*:0.1.0 |
| Draft as of 2026-05-04 | *Computable Name*:SenologieKDS |

# Kerndatensatz Senologie

Willkommen beim Implementation Guide für den **Kerndatensatz Senologie**.

Dieser Kerndatensatz definiert FHIR-Profile für die strukturierte Dokumentation der **Brustkrebsversorgung** an zertifizierten Brustzentren und darüber hinaus. Die technische Umsetzung erfolgt durch das **Berlin Institute of Health at Charité (BIH)**, die inhaltliche Abstimmung mit der **[Deutschen Gesellschaft für Senologie (DGS)](https://www.senologie.org/)**.

### Zielsetzung

Das Modul verfolgt drei Ziele:

1. **Standardisierte Erfassung**klinischer Daten entlang des Versorgungspfads Mammakarzinom — von der Erstvorstellung über Diagnostik, Therapie und Nachsorge
1. **Interoperabler Datenaustausch**zwischen klinischen Systemen, Krebsregistern und Forschungsdatenbanken auf Basis von HL7 FHIR
1. **Sekundärnutzung**der Versorgungsdaten für Qualitätssicherung, Versorgungsforschung und klinische Studien

### Klinischer Versorgungspfad

Das Modul bildet den gesamten klinischen Workflow der Senologie ab:

**FHIR Ressourcenmodell Senologie — Klinischer Versorgungspfad Mammakarzinom**

### Einordnung in die MII

Der Kerndatensatz nutzt bestehende MII-Kerndatensatzprofile als technische Basis, ist aber ein eigenständiger Datensatz — kein MII-Modul.

![](dgs-logo.png)

### Technische Abhängigkeiten

| | |
| :--- | :--- |
| [MII Onkologie](https://simplifier.net/medizininformatikinitiative-modulonkologie) | Diagnose, Operation, Systemtherapie, Strahlentherapie |
| [MII Pathologie](https://simplifier.net/medizininformatikinitiative-modulpathologie) | Pathologiebefund, Präparat |
| [MII Bildgebung](https://simplifier.net/medizininformatikinitiative-modulbildgebung) | Tumorlokalisation (BodyStructure) |
| [ISiK 5.0](https://simplifier.net/isik) | Basisprofil-Kompatibilität |
| [HL7 SDC](http://hl7.org/fhir/uv/sdc/) | Formularbasierte Datenerfassung |

### Leitlinien und Standards

Die Profilierung orientiert sich an:

* **S3-Leitlinie Mammakarzinom** (AWMF 032-045OL) – Leitlinien-Annotation
* **Onkologischer Basisdatensatz (oBDS)** — Krebsregistermeldungen
* **DKG-Zertifizierungskriterien** für Brustzentren

### Designprinzip: Formular-First

Die Datenerfassung erfolgt über **SDC-Questionnaires**, die sich am klinischen Workflow orientieren. Im Hintergrund werden die Formulardaten über Definition-based Extraction in domänenbasierte FHIR-Ressourcen überführt — aus einer Operationsdokumentation entstehen so einzelne Prozeduren, Implantate und Komplikationen. Siehe [Erfassung](anwendungsfaelle-erfassung.md).

### Übersicht

* [Datenmodell](datenmodell.md) — Logisches Modell und FHIR-Mapping
* [Profile](profilbeschreibungen.md) — Alle FHIR-Profile im Detail
* [Testpatientinnen](testpatientinnen.md) — Zwei durchgängige Beispielfälle (kurativ + palliativ)
* [Anwendungsfälle](anwendungsfaelle-uebersicht.md) — Erfassung, Austausch, Auswertung, Meldedatensätze
* [Terminologie](terminologie-uebersicht.md) — ValueSets, CodeSystems, ConceptMaps
* [Offene Fragen](offene-fragen.md) — Ballot-Fragen zur Kommentierung
* [Artifacts](artifacts.md) — Alle FHIR-Artefakte

### Geplante Weiterentwicklungen

Die folgenden Themen sind für zukünftige Versionen vorgesehen:

* **Implantateregister-Meldung (IRegG)** — StructureMaps für die automatische Ableitung von Implantateregisterdaten aus Device- und Procedure-Ressourcen, analog zum [oBDS-Transformationsansatz](meldung-obds.md)
* **CQL-basierte Qualitätsindikatoren** — Formale Definition der DKG-Kennzahlen und deskriptiver Statistiken als [CQL](http://cql.hl7.org/) Measures für automatisierte Auswertung
* **Synthetische Testkohorte** — Regelbasiert generierte Testdaten (100 Patientinnen mit Variation von Subtypen, Stadien und Therapien) als Docker-Container für SQL on FHIR und CQL-Auswertungen
* **PRO-Integration** — Referenzierung von PRO-CTCAE und EORTC QLQ-BR42 aus dem MII PRO-Modul für therapiebegleitende Patientinnenbefragungen

