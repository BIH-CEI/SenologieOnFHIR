# OncoBox / DKG-Zertifizierung - Kerndatensatz Senologie v0.9.0

* [**Table of Contents**](toc.md)
* [**Meldewege**](anwendungsfaelle-meldedatensaetze.md)
* **OncoBox / DKG-Zertifizierung**

## OncoBox / DKG-Zertifizierung

# OncoBox-Brust-Transformation (OnkoZert / DKG-Brustzentrum-Zertifizierung)

### Überblick

Zertifizierte Brustzentren übermitteln jaehrlich ihre Fall- und Qualitätsindikatordaten in Form einer **OncoBox-Brust-XML-Meldung** an [OnkoZert](https://xml-oncobox.de/de/Zentren/BrustZentren), die Zertifizierungsstelle der Deutschen Krebsgesellschaft (DKG). Diese Transformation erzeugt **OncoBox-Brust-konforme Meldungen aus klinischen FHIR-Daten**, die auf den Senologie-Profilen dieses IGs basieren.

* **Qüllformat**: FHIR Bundle mit Senologie-Profilen (dieser IG)
* **Zielformat**: OncoBox Brust, Spezifikation **N1.1.1**
* **Methode**: FHIR StructureMaps (FML) mit OncoBox Logical Model als Zielstruktur
* **Ausführung**: [Matchbox](https://github.com/ahdis/matchbox) als lokale ETL-Strecke
* **Scope**: **OncoBox Brust N1.1.1** mit **OncoBox 2.0 FM-Erweiterung (J03-J05)** – nicht OncoBox Darm/Prostata/Lunge

### Architektur

Die Transformation folgt dem gleichen Muster wie die [oBDS-](meldung-obds.md), [IRegG-](meldung-ireg.md) und [IQTIG-Transformation](meldung-iqtig.md): FHIR-Ressourcen werden über StructureMaps auf ein Logical Model abgebildet, das anschliessend als XML serialisiert wird (OncoBox-Exportformat).

```
┌─────────────────────────────┐
│  FHIR Bundle                │
│  (Senologie-Profile)        │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│  StructureMap (FML)         │
│  Orchestrator + Teil-Maps   │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│  OncoBox Logical Model      │
│  (OncoBoxBrustMeldung)      │
└──────────┬──────────────────┘
           │
           ▼
┌─────────────────────────────┐
│  Matchbox $transform        │
│  → OncoBox XML (N1.1.1)     │
└─────────────────────────────┘

```

Die OncoBox-Brust-Meldung besteht aus:

* **Zentrum** – OnkoZert-Zentrumskennung, Berichtszeitraum
* **Primaerfall** (1..*) – ein Eintrag je Patientin/Fall mit Diagnose, Therapie, Verlauf
* **Kennzahlen KB-1 bis KB-20** – aggregierte DKG-Qualitätsindikatoren (Zaehler/Nenner)

### StructureMap-Übersicht

| | | | |
| :--- | :--- | :--- | :--- |
| **SenologieToOncoBoxBrust** | Orchestrator: dispatcht an Teil-Maps | Bundle (alle Profile) | OncoBoxBrustMeldung |
| **SenologieToOncoBoxBrustZentrum** | Organization + Metadaten | Organization | zentrum |
| **SenologieToOncoBoxBrustPrimaerfall** | Patient + Condition + Encounter + Diagnose-Block | Patient, Condition, Encounter, Observation, CarePlan, ResearchSubject | primaerfall |
| **SenologieToOncoBoxBrustOperation** | OP + Specimen + Pathologie | Procedure, Specimen, Observation | primaerfall.operation |
| **SenologieToOncoBoxBrustTherapie** | Systemtherapie + Strahlentherapie | Procedure (Senologie_Systemtherapie, _Strahlentherapie) | primaerfall.systemtherapie / .strahlentherapie |
| **SenologieToOncoBoxBrustVerlauf** | Verlauf + OncoBox 2.0 FM-Felder (J03-J05) | Observation (FM), Condition (Rezidiv), Procedure (OP/Syst/ST) | primaerfall.verlauf |
| **SenologieToOncoBoxBrustKennzahlen** | Shell-Eintraege KB-1 bis KB-20 | Bundle (Aggregation) | kennzahl |

### Mapping-Tabellen

#### Zentrum (Meldungsmetadaten)

| | | |
| :--- | :--- | :--- |
| OncoBox_Version | fest: N1.1.1 | Spezifikationsversion |
| Zentrum_ID | Organization.identifier (onkozert-zentrum-id) | OnkoZert-Kennung; Fallback: IKNR |
| Zentrum_Name | Organization.name | Name des Brustzentrums |
| IKNR | Organization.identifier (arge-ik/iknr) | Institutionskennzeichen |
| Standort_ID | Organization.identifier (standortnummer) | Standort |
| Berichtszeitraum | Transformationsparameter | i.d.R. 01.07.Vorjahr – 30.06.lfd.Jahr |
| Meldungsdatum | Bundle.timestamp | Zeitpunkt der Meldungserstellung |

#### Primaerfall – Patient + Fall

| | | |
| :--- | :--- | :--- |
| Fall_ID | Condition.id | Pseudonymisiert |
| Patient_Pseudonym | Patient.id | Zentrumsinternes Pseudonym |
| Primaerfallart | Condition.code (ICD-10-GM Prefix) | C50=1, D05=2, Z40=7, Z42=8, D24=9 |
| Patient_Geburtsdatum | Patient.birthDate |   |
| Patient_Geschlecht | Patient.gender | W/M/D/U |
| Patient_PLZ | Patient.address.postalCode |   |
| Patient_Menopausenstatus | Observation (LOINC 86805-9) | 1=prä, 2=peri, 3=post |
| Fall_Typ | Encounter.class | 1=stat, 2=amb, 3=teilstat |
| Fall_Aufnahmedatum / Fall_Entlassungsdatum | Encounter.period |   |

#### Primaerfall – Diagnose

| | | |
| :--- | :--- | :--- |
| Diagnose_Datum | Condition.onsetDateTime |   |
| Diagnose_ICD | Condition.code (ICD-10-GM) | Code + Version |
| Diagnose_Dignität | ICD-10-GM-Prefix | C50=1 maligne, D05=2 in-situ, D24=4 benigne |
| Diagnose_Seite | Condition.bodySite (SNOMED) | R/L/B |
| Diagnose_ICDO | Observation (LOINC 59847-4) | ICD-O-3 Morphologie |
| Diagnose_Grading | Observation (LOINC 33732-9) | G1-G4, GX |
| Bildgebung | Observation (Senologie_Bildgebung_Observation) | Methode, BI-RADS, Datum |
| cTNM | Observation (LOINC 21908-9 + Komponenten) | cT/cN/cM/UICC |
| pTNM | Observation (LOINC 21902-2 + Komponenten) | pT/pN/pM/L/V/Pn/UICC |
| Lymphknoten | Observations (LOINC 21894-1 / 21893-3 / 92832-5 / 92833-3) | untersucht/befallen + Sentinel |
| Rezeptorstatus ER/PR/HER2 | Observations (LOINC 85337-4 / 85339-0 / 85319-2) | P/N/U |
| Diagnose_Histo_Präop | Specimen.type (SNOMED) | OncoBox 2.0: Stanze=1, Vakuum=2, FNA=3, offen=4, keine=0 |

#### Primaerfall – Operation

| | | |
| :--- | :--- | :--- |
| Op_Datum | Procedure.performed |   |
| Op_Seite | Procedure.bodySite (SNOMED) | R/L/B |
| Op_OPS | Procedure.code.coding (OPS) |   |
| Op_Art | Procedure.code (OPS-Prefix) | BET (5-870)=1, Mast einfach (5-871)=2, SSM (5-872)=3, NSM (5-883)=4, Rekon (5-885)=6, Axilla (5-402)=7, SLNB (5-401.1)=8 |
| Op_Drahtmarkierung | Senologie_OP_Planung.extension preOpMarkierung | N=0, S=1, M=2, T=3 |
| Op_Sentinel | OPS 5-401.1* | 0/1 |
| Op_Axdissektion | OPS 5-402* | 0/1 |
| Op_Schnellschnitt | Specimen.processing (SNOMED 123038009) | 0/1 |
| Op_Praeparatkontrolle | Specimen.processing.procedure (SNOMED) | Mammo=1, Sono=2 |
| Op_R_Lokal / Op_R_Gesamt | Procedure.outcome (SNOMED) | R0-RX |
| Op_Revision | Procedure.reasonCode (SNOMED 282032007 / Text) | OncoBox 2.0: Revisionsoperation 0/1 |
| Op_Anzahl_bis_R0 | Procedure-Aggregation (CQL) | OncoBox 2.0: Default 1 bei R0, CQL-Aggregation für Kette (KB-14) |
| Op_Komplikation | Senologie_Operative_Komplikation | Kürzel + ICD |

#### Primaerfall – Therapie

| | | |
| :--- | :--- | :--- |
| Systemtherapie | Senologie_Systemtherapie_Procedure | Art, Stellung, Protokoll, Zeitraum |
| Syst_Trastuzumab | Procedure.note enthaelt "Trastuzumab" | KB-7-relevantes Flag |
| Syst_Stellung | Procedure.extension therapiestellung | N/A/P |
| Endokrine_Therapie | Senologie_Systemtherapie_Procedure (endokrin) | Tamoxifen, AI, GnRH |
| Strahlentherapie | Senologie_Strahlentherapie | Beginn/Ende, Zielgebiet, Stellung |
| Tumorkonferenz | CarePlan (Senologie_Tumorboard) | Typ: prätherapeutisch / postoperativ / Rezidiv |
| Psychoonkologie | Procedure / Observation | erfolgt 0/1 |
| Sozialdienst | Procedure / Observation | erfolgt 0/1 |
| Studienteilnahme | ResearchSubject | teilgenommen 0/1 |
| Stud_Name_Code (K02) | ResearchSubject.extension[StudiennameCode] | OncoBox 2.0: Studienname aus Auswahlliste |
| Stud_Screening (K03) | ResearchSubject.extension[Studienscreening] | OncoBox 2.0: Screening zur Studienteilnahme 0/1 |

#### Primaerfall – Verlauf + OncoBox 2.0 FM-Felder (J03-J05)

| | | |
| :--- | :--- | :--- |
| Verlauf_Datum | Observation.effectiveDateTime (FM) / Condition.recordedDate (Rezidiv) | Datum des Verlaufsereignisses |
| Verlauf_Ereignis | Observation LOINC 21907-1 -> 3 (FM); Condition.code SNOMED -> 1/2/4 | 1=Lokal, 2=Regional, 3=FM, 4=Kontralateral |
| **FM_OP_Datum (J03)** | Procedure.performedDateTime (Operation, Intention=P) | Nur bei ereignis=3: Operationsdatum bei FM |
| **FM_Therapien (J04)** | Existenz-Check Procedure-Ressourcen (Intention=P) im Bundle | OP/Syst/ST/Endo: jeweils 0/1 |
| FM_Th_OP | Procedure (senologie-operation, Intention=P) vorhanden | 0=nein, 1=ja |
| FM_Th_Syst | Procedure (senologie-systemtherapie, Intention=P) vorhanden | 0=nein, 1=ja |
| FM_Th_ST | Procedure (senologie-strahlentherapie, Intention=P) vorhanden | 0=nein, 1=ja |
| FM_Th_Endo | Procedure (senologie-systemtherapie, endokrin, Intention=P) vorhanden | 0=nein, 1=ja |
| FM_Th_Sonst | – | Derzeit nicht automatisch ableitbar |
| **FM_Residualstatus (J05)** | Procedure.outcome (Operation, Intention=P) | R0/R1/R2/RX |

Die OncoBox 2.0 FM-Felder (J03-J05) erweitern den Verlauf-Block um therapiebezogene Details bei Fernmetastasen. FM-spezifische Procedures werden anhand der palliativen Therapie-Intention (`extension:Intention` = P) identifiziert. Die Felder sind nur relevant wenn `Verlauf_Ereignis = 3` (Fernmetastase).

### DKG-Kennzahlen (KB-1 bis KB-20)

Die OncoBox erwartet pro Kennzahl einen **Zaehler/Nenner-Block** gemaess DKG-Erhebungsbogen. Die 20 Kennzahlen sind in der Excel-Spezifikation (`OncoBoxBrust_N1.1.1_Spec.xlsx`) jeweils als eigenes Sheet KB-1 bis KB-20 definiert mit Einschlusskriterien für Nenner, Erfüllungskriterium für Zaehler und Sollwert.

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| KB-1 | Postop. Fallbesprechung | CarePlan (Typ=postoperativ) | Postop. Tumorkonferenz vorhanden | Alle Primaerfaelle mit OP | >=95% |
| KB-2 | Präth. Fallbesprechung | CarePlan (Typ=prätherapeutisch) | Prätherap. Tumorkonferenz vorhanden | Invasive Primaerfaelle | >=95% |
| KB-3 | Fallbespr. Rezidiv/Metas. | CarePlan (Typ=rezidiv) | Tumorkonferenz vorhanden | Rezidive + Metastasen | >=90% |
| KB-4 | Adj. Chemo (invasiv) | Senologie_Systemtherapie (adj. Chemo) | Adj. Chemo erhalten | Indizierte pT1c+N+/pT2+/Hochrisiko | >=80% |
| KB-5 | Adj. Chemo (DCIS) | – | Bei DCIS keine Chemo | DCIS-Faelle | >=95% |
| KB-6 | Endokrine Therapie | Senologie_Systemtherapie (endokrin) | Endokrine Therapie erhalten | HR+ invasive Primaerfaelle | >=85% |
| KB-7 | Trastuzumab | Senologie_Systemtherapie (Trastuzumab) | Trastuzumab erhalten | HER2+ Primaerfaelle pT1c+ | >=95% |
| KB-8 | First-Line-Therapie | Senologie_Systemtherapie (palliativ, FirstLine) | First-Line eingeleitet | Primaer metastasierte Faelle | >=80% |
| KB-9 | Psychoonkologie | Procedure/Observation (Psychoonko) | Psychoonkol. Kontakt | Alle Primaerfaelle | >=80% |
| KB-10 | Sozialdienst | Procedure/Observation (Sozialdienst) | Sozialdienstkontakt | Alle Primaerfaelle | >=80% |
| KB-11 | Studien | ResearchSubject | In Studie eingeschrieben | Alle Primaerfaelle | >=5% |
| KB-12 | Histol. Sicherung | Biopsie-Procedure vor OP-Datum | Präop. B-Biopsie vorhanden | Invasive Primaerfaelle | >=90% |
| KB-13 | Fallzahl | – | Primaerfaelle + Rezidive + Metas. | Berichtszeitraum | >=100 Primaerfaelle |
| KB-14 | Eingriffe bis R0 | Anzahl OPs je Fall | <=2 Eingriffe bis R0 | Alle operierten Faelle | >=90% |
| KB-15 | BET-Rate pT1 | Procedure.code (OPS 5-870*) | BET durchgeführt | pT1-Primaerfaelle | >=70% |
| KB-16 | Mastektomien | Procedure.code (OPS 5-871/872/883*) | Mastektomie | Alle operierten Faelle | keine |
| KB-17 | LK-Entfernung | Observation (LK untersucht) | >=10 LK untersucht | Invasive pT1+ mit ALND | >=95% |
| KB-18 | Drahtmarkierung | Senologie_OP_Planung.extension preOpMarkierung | Markierung erfolgt | Nicht-tastbare Befunde | >=95% |
| KB-19 | Revisionsop. | Procedure.reasonCode "Revision" | Keine Revision | Alle operierten Faelle | >=95% |
| KB-20 | Checkliste | – | Organisatorisch | – | – |

#### Aggregationsmodell

Die 20 Kennzahlen werden nicht durch ein 1:1-Mapping erzeugt, sondern durch **Aggregation aller Primaerfaelle des Berichtszeitraums**. Zwei Umsetzungsoptionen:

1. **Shell-Mapping + Auswerteschicht** (dieser IG): Der Orchestrator legt pro KB einen Shell-Eintrag (ID + Bezeichnung, Zaehler=0, Nenner=0) an. Die Zaehler/Nenner-Werte werden von einer nachgelagerten CQL-basierten Auswerteschicht aggregiert und in die OncoBox-Meldung geschrieben. Siehe [Anwendungsfall Auswertung](anwendungsfaelle-auswertung.md) und `input/cql/`.
1. **Pre-Aggregation durch das Zentrum**: Das Zentrum erzeugt die KB-Werte bereits vor der Transformation (z.B. im Dashboard) und übergibt sie als Parameter oder als vorgefertigte FHIR MeasureReports. Die StructureMap mappt die MeasureReport-Werte direkt in den Kennzahl-Block.

### Crosswalk zu anderen Meldeformaten

Viele OncoBox-Datenpunkte überlappen konzeptionell mit oBDS-, IQTIG- und S3-Leitlinien-Qualitätsindikatoren. Die Senologie-FHIR-Profile bilden die **gemeinsame klinische Datenbasis**; die Transformationen ziehen jeweils die für das Zielformat erforderlichen Felder.

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| OP-Datum, OPS-Kodes | Ja (Operation) | Ja (O:OPSCHLUESSEL) | Ja (Op_OPS) | – |
| ICD-10-GM Diagnose | Ja (Diagnose) | Ja (BRUST:DIAGICD) | Ja (Diagnose_ICD) | – |
| Histologie (ICD-O-3) | Ja | Ja (O:HISTMORPH) | Ja (Diagnose_ICDO) | – |
| pTNM / Grading | Ja (pTNM) | Ja | Ja | QI5, QI6 |
| Rezeptorstatus ER/PR/HER2 | Ja (Modul_Mamma) | Ja (O:ERSTATUS etc.) | Ja (Rezeptorstatus) | QI12, QI13 |
| Residualstatus R0/R1/R2 | Ja (Residualstatus) | Ja (O:RSTATUSLOK/GES) | Ja (Op_R_Lokal/Gesamt) | – |
| Lymphknoten (untersucht/befallen) | Ja (Histologie) | Ja | Ja (Lymphknoten) | KB-17 = S3 QI zur LK |
| Drahtmarkierung | – | Ja (BRUST:DRAHT) | Ja (Op_Drahtmarkierung) | KB-18 = S3 QI7 |
| Tumorkonferenz | Ja (Tumorkonferenz) | Ja (BRUST:TKPRAEOP) | Ja (Tumorkonferenz) | KB-1, KB-2 = S3 QI1, QI2 |
| Trastuzumab bei HER2+ | Ja (Systemtherapie) | – | Ja (Syst_Trastuzumab) | KB-7 = S3 QI14 |
| Adjuvante endokrine Therapie | Ja (Systemtherapie) | – | Ja (Endokrine_Therapie) | KB-6 = S3 QI15 |
| Psychoonkologie | – | – | Ja (Psychoonkologie) | KB-9 |
| Sozialdienst | – | – | Ja (Sozialdienst) | KB-10 |
| Studienteilnahme | Ja (Studie) | – | Ja (Studienteilnahme) | KB-11 |

Für Felder, die auch in der IQTIG-Meldung enthalten sind, verwenden die OncoBox-Maps dieselbe FHIR-Qülle wie `SenologieToIqtigBrust` / `SenologieToIqtigOperation`. Die Code-Übersetzung kann aufgrund unterschiedlicher Zielschluessel (IQTIG numerisch vs. OncoBox gemischt) abweichen.

### Code-Übersetzung

Die OncoBox-Brust-Meldung verwendet eigene Schluessel, die sich zum Teil an oBDS und DKG-Konventionen orientieren:

| | | | |
| :--- | :--- | :--- | :--- |
| Geschlecht | Patient.gender | W/M/D/U | Direkte Zuordnung in FML |
| Seitenlokalisation | SNOMED CT | R/L/B | Direkte Zuordnung in FML |
| Primaerfallart | ICD-10-GM Prefix | 1-9 (C50, D05, D24, Z40, Z42, …) | Prefix-basiert |
| Operationsart | OPS Prefix | 1-9 (BET, Mast einfach, SSM, NSM, Rekon, …) | Prefix-basiert |
| Residualstatus | SNOMED CT (122538001 etc.) | R0/R1/R2/RX | Direkte Zuordnung in FML |
| Bildgebende Methode | SNOMED CT | 1-9 (Mammo, Sono, MRT, Tomo, …) | Direkte Zuordnung in FML |
| Therapiestellung | Senologie-Extension | N/A/P (neo/adj/pall) | Direkte Zuordnung in FML |
| Rezeptorstatus | SNOMED CT (10828004/260385009/261665006) | P/N/U | Direkte Zuordnung in FML |

### Datenverfuegbarkeit und offene Luecken

Nicht alle OncoBox-Pflichtfelder koennen aus den Senologie-Profilen abgeleitet werden. Insbesondere die Kennzahlen-Aggregation erfordert eine dedizierte Auswerteschicht. Die folgende Tabelle zeigt den Status je Datenpunkt.

| | | |
| :--- | :--- | :--- |
| Zentrum_ID, IKNR, Standort | Organization (KIS/Stammdaten) | **Externe Qülle**– nicht klinisch |
| Berichtszeitraum | Transformationsparameter | **Externe Qülle**– meldungsspezifisch |
| Primaerfallart (feingranular) | Ableitung aus ICD + Verlauf | **Teilweise**– OnkoZert-Systematik (Sheet "Primaerfallarten") nicht 1:1 abbildbar |
| OP-Datum, OPS, Seitenlokalisation | Senologie_Operation / _BrustOP | Vorhanden |
| ICD-10-GM, Diagnosedatum | Senologie_Diagnose_Maligne / _Benigne | Vorhanden |
| Histologie ICD-O-3, Grading | Senologie_Pathologie_Befund | Vorhanden |
| cTNM / pTNM (T/N/M + Version + UICC) | MII-Onko TNM-Klassifikation | Vorhanden |
| pTNM Detail (ySymbol, L/V/Pn) | MII-Onko TNM-Klassifikation Komponenten | Vorhanden |
| pTNM Groesse DCIS | Pathologie Observation (LOINC 44648-0) | Vorhanden |
| pTNM Multifokalität | Observation (LOINC 44638-1, SNOMED) | Vorhanden |
| Rezeptorstatus ER/PR/HER2, Ki-67 | MII-Onko-Observations | Vorhanden |
| Lymphknotenstatus (regionaer + Sentinel) | Senologie_Pathologie_Befund | Vorhanden |
| Drahtmarkierung | Senologie_OP_Planung (Extension preOpMarkierung) | Vorhanden |
| Residualstatus R0/R1/R2 | Senologie_Operation.outcome | Vorhanden |
| BI-RADS, bildgebende Methode | Senologie_Bildgebung_Observation / _Befund | Vorhanden |
| Präoperative histologische Sicherung (Biopsie-Typ) | Procedure (Biopsie-OPS) | **Teilweise**– KB-12-Binding fehlt |
| Trastuzumab-Flag | Senologie_Systemtherapie_Procedure.note / Medikation | **Teilweise**– aktüll Freitext-basiert, Binding über ATC L01FD01 empfohlen |
| First-Line-Therapie bei Metastasierung | Senologie_Systemtherapie_Procedure (Stellung=palliativ + erste) | **Teilweise**– Ordnung muss abgeleitet werden |
| Menopausenstatus | Observation (Modul Mamma) | **Teilweise**– Observation-Binding fehlt in Senologie-Profilen |
| Psychoonkologie / Sozialdienst | Procedure / Observation | **Teilweise**– eigene Profile nicht vorhanden; ableitbar über CarePlan oder Procedure.category |
| Studienteilnahme | ResearchSubject / Senologie_Studienteilnahme | Vorhanden |
| Studienname Auswahlliste (K02) | ResearchSubject.extension[StudiennameCode] | **Vorhanden**– OncoBox 2.0 |
| Screening Studienteilnahme (K03) | ResearchSubject.extension[Studienscreening] | **Vorhanden**– OncoBox 2.0 |
| Verlauf_Datum / Verlauf_Ereignis | Observation (FM) / Condition (Rezidiv) | Vorhanden |
| FM_OP_Datum (J03) | Procedure (Operation, Intention=P) | Vorhanden |
| FM_Therapien (J04) | Procedure-Existenz-Check (OP/Syst/ST/Endo, Intention=P) | Vorhanden |
| FM_Residualstatus (J05) | Procedure.outcome (Operation, Intention=P) | Vorhanden |
| Anzahl Eingriffe bis R0 (KB-14) | Aggregation Procedure (pro Fall) | **Aggregationsschritt**– CQL erforderlich |
| BET-Rate bei pT1 (KB-15) | Aggregation (Op_Art + pTNM) | **Aggregationsschritt**– CQL erforderlich |
| Tumorkonferenz-Typ (prä/post/rezidiv) | CarePlan.category | **Teilweise**– CodeSystem für Typ zu ergänzen |
| Kennzahlen KB-1 bis KB-20 (Zaehler/Nenner) | Aggregationsschicht | **Extern / CQL**– siehe Aggregationsmodell |

#### Handlungsoptionen

Analog zur IQTIG-Transformation gilt:

1. **Senologie-Profile erweitern** – Tumorkonferenz-Typ als CodeSystem, Psychoonko-/Sozialdienst-Profile ergänzen, Trastuzumab-Binding über ATC, First-Line-Flag am Systemtherapie-Profil.
1. **Eigene OncoBox-Aggregationsschicht (CQL)** – Die 20 Kennzahlen werden in CQL-Measure-Definitionen abgebildet und über eine FHIR-Measure-Evaluation aggregiert. Die Ergebnisse (MeasureReports) werden in die OncoBox-Kennzahl-Blocks gemappt. S3-Leitlinien-QI und KB-Kennzahlen überlappen zu grossen Teilen – entsprechende Wiederverwendung zwischen Leitlinien-QI-Measures und KB-Measures ist angestrebt.
1. **ETL-Strecke** – Zentrum-ID, Berichtszeitraum und administrative Metadaten werden aus der OnkoZert-Konfiguration nachgezogen. Die ETL kombiniert FHIR-Primaerfaelle + CQL-MeasureReports + administrative Metadaten zu einer vollständigen OncoBox-XML-Meldung.

**Empfehlung**: Kombination aus Option 1 (klinische Profil-Erweiterungen), Option 2 (CQL-Aggregationsschicht) und Option 3 (ETL für Metadaten). Die hier bereitgestellten StructureMaps decken den **primaerfallbezogenen Teil** ab; die Kennzahlen-Befüllung ist ein separater Aggregationsschritt.

### OncoBox-Spezifikation

Die Transformation basiert auf der **OncoBox Brust Spezifikation N1.1.1**:

* **Spezifikation**: N1.1.1 (Excel-Workbook mit 25+ Sheets)
* **Logical Model**: [OncoBoxBrustMeldung](StructureDefinition-oncobox-brust-meldung.md) – bildet die XML-Struktur als FHIR-StructureDefinition ab
* **Datenfelder**: Sheet "Datenfelder-XML" (91 Datenfelder mit Typ, Kode, Beschreibung)
* **Strukturvalidierung**: Sheet "Strukturval." (148 Validierungsregeln)
* **Primaerfallarten**: Sheet "Primaerfallarten" (103 Zeilen; OnkoZert-Klassifikation der Fallarten)
* **Kennzahlen**: Sheets KB-1 bis KB-20 (Zaehler/Nenner/Sollwert je Indikator)
* **Offizielle Qülle**: [OnkoZert XML OncoBox Brustzentren](https://xml-oncobox.de/de/Zentren/BrustZentren)
* **Scope**: OncoBox Brust N1.1.1 + OncoBox 2.0 FM-Erweiterung (J03-J05) – nicht OncoBox Darm/Prostata/Lunge

> **Hinweis**: Die OncoBox-Spezifikation wird durch OnkoZert/DKG regelmaessig aktualisiert. Die hier abgebildete Struktur entspricht der Spezifikation N1.1.1. Bei Aktualisierung der Spezifikation sind Logical Model und StructureMaps entsprechend zu versionieren. Die Qüll-Excel-Datei liegt unter `input/data/oncobox-brust/OncoBoxBrust_N1.1.1_Spec.xlsx`.

### Abgrenzung zu oBDS, IRegG und IQTIG

Die vier Meldeformate decken unterschiedliche regulatorische Zwecke ab und enthalten überlappende, aber nicht identische Datenpunkte:

| | | | |
| :--- | :--- | :--- | :--- |
| **oBDS** | Krebsregistermeldung | Klinisches Krebsregister | Pro klinisches Ereignis (Diagnose, Therapie, Verlauf, Tod) |
| **IRegG** | Implantatregistermeldung | BfArM / Implantateregister | Pro Implantationseingriff |
| **IQTIG 18.1** | Externe Qualitätssicherung (SGB V Paragraph 136) | IQTIG / G-BA | Pro Behandlungsfall Mammachirurgie |
| **OncoBox Brust** | DKG-Brustzentrum-Zertifizierung | OnkoZert (DKG) | Jaehrlich, aggregiert über Berichtszeitraum |

Die Senologie-FHIR-Profile bilden die gemeinsame klinische Datenbasis; die vier Transformations-Pipelines (StructureMaps) ziehen daraus jeweils die für das Zielformat erforderlichen Felder. Wo moeglich (z.B. TNM, Rezeptorstatus, Residualstatus, Lymphknoten) verwenden die Maps identische Qüll-Muster – bei abweichenden Zielschluesseln lediglich mit unterschiedlichem Output-Mapping.

### Ausführung

Die Transformation wird analog zur oBDS-, IRegG- und IQTIG-Transformation über [Matchbox](https://github.com/ahdis/matchbox) als lokale ETL-Strecke ausgeführt.

**Transformation:**

```
POST http://localhost:8080/fhir/StructureMap/$transform
Content-Type: application/fhir+json

{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "source",
      "resource": { /* FHIR Bundle mit Senologie-Ressourcen */ }
    },
    {
      "name": "source",
      "valüUri": "https://www.senologie.org/fhir/StructureMap/SenologieToOncoBoxBrust"
    }
  ]
}

```

Das Ergebnis ist eine Instanz des OncoBox Logical Models. Ein nachgelagerter XML-Serialisierer erzeugt daraus die OncoBox-Brust-XML-Datei im Format N1.1.1, die an OnkoZert übermittelt werden kann.

### Validierung der Transformationsergebnisse

Die folgenden Pflichtfelder werden durch die StructureMaps nicht befüllt und müssen durch das lokale KIS oder die ETL-Strecke ergänzt werden.

| | | |
| :--- | :--- | :--- |
| `zentrum.zentrumId` | Zentrums-ID für OnkoZert | KIS / Zentrumsadministration |
| `zentrum.berichtszeitraumBeginn/Ende` | Berichtszeitraum der Jahresmeldung | ETL-Konfiguration |
| `zentrum.meldungsdatum` | Zeitpunkt der Meldungsgenerierung | ETL-Strecke (automatisch) |
| `primaerfall.fall` | Fall-Referenz (Encounter) | KIS / Fallmanagement |
| `primaerfall.diagnose.seitenlokalisation` | Seite der Diagnose | Map-Erweiterung nötig (bodySite → Seite) |
| `primaerfall.diagnose.bildgebung.methode` | Bildgebende Methode (Mammographie, Sono, MRT) | Map-Erweiterung nötig (DiagnosticReport.code) |
| `primaerfall.operation.seitenlokalisation` | Seite der OP | Map-Erweiterung nötig (Procedure.bodySite) |
| `primaerfall.tumorkonferenz.typ` | Typ der TK (prä-/postoperativ) | Profil-Erweiterung nötig |
| `primaerfall.verlauf.vitalstatus` | Lebend/Verstorben zum Meldezeitpunkt | Map-Erweiterung nötig (Patient.deceased) |
| `kennzahl.kennzahlId` | 20x Kennzahl-IDs (KB-1 bis KB-20) | Map verwendet`id`statt`kennzahlId`— Feldname-Korrektur nötig |

