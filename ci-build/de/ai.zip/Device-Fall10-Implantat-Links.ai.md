# Fall 10: Brustimplantat links (Sofortrekonstruktion) - Kerndatensatz Senologie v0.10.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fall 10: Brustimplantat links (Sofortrekonstruktion)**

##  Device: Fall 10: Brustimplantat links (Sofortrekonstruktion)

-------

**German**

-------

Profil: [BIH LM Senologie Brustimplantat](StructureDefinition-senologie-implantat.md)

**status**: Active

**manufacturer**: Mentor

**lotNumber**: REF-2025-LB-001

**serialNumber**: IMP-2025-001-L

**type**: Silikon-Brustimplantat

**patient**: [Christina Becker Female, DoB: 1982-12-14 ( http://fhir.bih-charite.de/sid/patient-id#SENO-2025-010)](Patient-Fall10-Patient-Christina-Becker.md)



## Resource Content

```json
{
  "resourceType" : "Device",
  "id" : "Fall10-Implantat-Links",
  "meta" : {
    "profile" : ["https://www.senologie.org/fhir/StructureDefinition/senologie-implantat"]
  },
  "status" : "active",
  "manufacturer" : "Mentor",
  "lotNumber" : "REF-2025-LB-001",
  "serialNumber" : "IMP-2025-001-L",
  "type" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "465380004",
      "display" : "Silicone gel-filled breast implant"
    }],
    "text" : "Silikon-Brustimplantat"
  },
  "patient" : {
    "reference" : "Patient/Fall10-Patient-Christina-Becker"
  }
}

```
