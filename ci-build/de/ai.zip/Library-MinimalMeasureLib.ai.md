# Library: MinimalMeasureLib - Kerndatensatz Senologie v0.10.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Library: MinimalMeasureLib**

## Library: Library: MinimalMeasureLib 

| | |
| :--- | :--- |
| **:https://www.senologie.org/fhir/Library/MinimalMeasureLib | **:0.10.0 |
| Active | **:MinimalMeasureLib |

 
Minimale Debug-Library mit drei konstanten true-Defines 

-------

**German**

-------

* * **Content: **application/elm+json: ````Encoded data (7864 characters)````: **Id: **
  * ?: MinimalMeasureLib
* * **Content: **application/elm+json: ````Encoded data (7864 characters)````: **Version: **
  * ?: 0.10.0
* * **Content: **application/elm+json: ````Encoded data (7864 characters)````: **Url: **
  * ?: [Library: MinimalMeasureLib](Library-MinimalMeasureLib.md)
* * **Content: **application/elm+json: ````Encoded data (7864 characters)````: **Date: **
  * ?: 2026-10-12
* * **Content: **application/elm+json: ````Encoded data (7864 characters)````: **Publisher: **
  * ?: Berlin Institute of Health at Charité (BIH)
* * **Content: **application/elm+json: ````Encoded data (7864 characters)````: **Description: **
  * ?: Minimale Debug-Library mit drei konstanten true-Defines
* * **Content: **application/elm+json: ````Encoded data (7864 characters)````: **Topic: **
  * ?: C4872



## Resource Content

```json
{
  "resourceType" : "Library",
  "id" : "MinimalMeasureLib",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCode" : "CC-BY-4.0"
    },
    {
      "extension" : [{
        "url" : "packageId",
        "valueId" : "kds-senologie"
      },
      {
        "url" : "version",
        "valueString" : "0.10.0"
      },
      {
        "url" : "uri",
        "valueUri" : "https://www.senologie.org/fhir"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    }],
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablelibrary",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablelibrary"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "version" : "3.0.0",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  }],
  "url" : "https://www.senologie.org/fhir/Library/MinimalMeasureLib",
  "version" : "0.10.0",
  "name" : "MinimalMeasureLib",
  "title" : "Library: MinimalMeasureLib",
  "status" : "active",
  "experimental" : false,
  "type" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/library-type",
      "code" : "logic-library"
    }]
  },
  "date" : "2026-10-12",
  "publisher" : "Berlin Institute of Health at Charité (BIH)",
  "contact" : [{
    "name" : "Berlin Institute of Health at Charité (BIH)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org"
    }]
  }],
  "description" : "Minimale Debug-Library mit drei konstanten true-Defines",
  "topic" : [{
    "coding" : [{
      "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
      "code" : "C4872",
      "display" : "Breast Carcinoma"
    }]
  }],
  "author" : [{
    "name" : "Berlin Institute of Health at Charité (BIH)",
    "telecom" : [{
      "system" : "email",
      "value" : "thomas.debertshaeuser@charite.de"
    }]
  }],
  "editor" : [{
    "name" : "Berlin Institute of Health at Charité (BIH)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org"
    }]
  }],
  "reviewer" : [{
    "name" : "Deutsche Gesellschaft für Senologie (DGS)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.senologie.org"
    }]
  }],
  "endorser" : [{
    "name" : "Deutsche Gesellschaft für Senologie (DGS)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.senologie.org"
    }]
  }],
  "content" : [{
    "contentType" : "text/cql",
    "data" : "Ly8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PQovLyBDUUwgTGlicmFyeTogTWluaW1hbE1lYXN1cmVMaWIKLy8KLy8gTWluaW1hbHN0ZSBMaWJyYXJ5IHp1bSBEZWJ1Z2dlbiB2b24gSEFQSSBDbGluaWNhbCBSZWFzb25pbmcuIERyZWkKLy8gRGVmaW5lcyBkaWUgaW1tZXIgdHJ1ZSB6dXJ1ZWNrZ2ViZW4g4oCUIGJlaSBOIFBhdGllbnRlbiBpbSBTZXJ2ZXIKLy8gbXVzcyBkaWUgTWVhc3VyZSBkYW5uIE4vTiA9IDEwMCAlIG1lbGRlbi4KLy8KLy8gSXRlcmF0aXZlIFZvcmdlaGVuc3dlaXNlOiBlcnN0IHNpY2hlcnN0ZWxsZW4gZGFzcyBkaWVzZSBMaWJyYXJ5Ci8vIGZ1bmt0aW9uaWVydCwgZGFubiBLb21wbGV4aXRhZXQgc2Nocml0dHdlaXNlIGVyaG9laGVuLgovLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09CgpsaWJyYXJ5IE1pbmltYWxNZWFzdXJlTGliIHZlcnNpb24gJzAuMS4wJwoKdXNpbmcgRkhJUiB2ZXJzaW9uICc0LjAuMScKCmluY2x1ZGUgRkhJUkhlbHBlcnMgdmVyc2lvbiAnNC4wLjEnCgpjb250ZXh0IFBhdGllbnQKCmRlZmluZSAiSW5Jbml0aWFsUG9wdWxhdGlvbiI6CiAgdHJ1ZQoKZGVmaW5lICJJbkRlbm9taW5hdG9yIjoKICB0cnVlCgpkZWZpbmUgIkluTnVtZXJhdG9yIjoKICB0cnVlCgovLyBTdGVwIDI6IGVjaHRlIENRTC1Mb2dpawovLyBIYXQgZGllc2VyIFBhdGllbnQgZWluZSBNYW1tYS1DYS1EaWFnbm9zZSAoU05PTUVEIDI1NDgzNzAwOSk/CmRlZmluZSAiSGFzTWFtbWFDYSI6CiAgZXhpc3RzKFtDb25kaXRpb25dIEMKICAgIHdoZXJlIGV4aXN0cyhDLmNvZGUuY29kaW5nIGMKICAgICAgd2hlcmUgYy5zeXN0ZW0gPSAnaHR0cDovL3Nub21lZC5pbmZvL3NjdCcgYW5kIGMuY29kZSA9ICcyNTQ4MzcwMDknKSkKCi8vIFN0ZXAgMzogSGF0IFBhdGllbnQgZWluZSBCRVQgKE9QUyA1LTg3MC4qKT8KZGVmaW5lICJIYXNCRVQiOgogIGV4aXN0cyhbUHJvY2VkdXJlXSBQCiAgICB3aGVyZSBleGlzdHMoUC5jb2RlLmNvZGluZyBjCiAgICAgIHdoZXJlIGMuc3lzdGVtID0gJ2h0dHA6Ly9maGlyLmRlL0NvZGVTeXN0ZW0vYmZhcm0vb3BzJyBhbmQgYy5jb2RlLnN0YXJ0c1dpdGgoJzUtODcwJykpKQo=",
    "title" : "MinimalMeasureLib.cql"
  },
  {
    "contentType" : "application/elm+json",
    "data" : "eyJsaWJyYXJ5Ijp7ImFubm90YXRpb24iOlt7InR5cGUiOiJDcWxUb0VsbUluZm8iLCJ0cmFuc2xhdG9yVmVyc2lvbiI6IjQuNy4wIiwidHJhbnNsYXRvck9wdGlvbnMiOiIiLCJzaWduYXR1cmVMZXZlbCI6Ik92ZXJsb2FkcyJ9XSwiaWRlbnRpZmllciI6eyJpZCI6Ik1pbmltYWxNZWFzdXJlTGliIiwidmVyc2lvbiI6IjAuMS4wIn0sInNjaGVtYUlkZW50aWZpZXIiOnsiaWQiOiJ1cm46aGw3LW9yZzplbG0iLCJ2ZXJzaW9uIjoicjEifSwidXNpbmdzIjp7ImRlZiI6W3sibG9jYWxJZGVudGlmaWVyIjoiU3lzdGVtIiwidXJpIjoidXJuOmhsNy1vcmc6ZWxtLXR5cGVzOnIxIiwiYW5ub3RhdGlvbiI6W119LHsibG9jYWxJZGVudGlmaWVyIjoiRkhJUiIsInVyaSI6Imh0dHA6Ly9obDcub3JnL2ZoaXIiLCJ2ZXJzaW9uIjoiNC4wLjEiLCJhbm5vdGF0aW9uIjpbXX1dfSwiaW5jbHVkZXMiOnsiZGVmIjpbeyJsb2NhbElkZW50aWZpZXIiOiJGSElSSGVscGVycyIsInBhdGgiOiJGSElSSGVscGVycyIsInZlcnNpb24iOiI0LjAuMSIsImFubm90YXRpb24iOltdfV19LCJjb250ZXh0cyI6eyJkZWYiOlt7Im5hbWUiOiJQYXRpZW50IiwiYW5ub3RhdGlvbiI6W119XX0sInN0YXRlbWVudHMiOnsiZGVmIjpbeyJuYW1lIjoiUGF0aWVudCIsImNvbnRleHQiOiJQYXRpZW50IiwiYW5ub3RhdGlvbiI6W10sImV4cHJlc3Npb24iOnsidHlwZSI6IlNpbmdsZXRvbkZyb20iLCJhbm5vdGF0aW9uIjpbXSwic2lnbmF0dXJlIjpbXSwib3BlcmFuZCI6eyJ0eXBlIjoiUmV0cmlldmUiLCJkYXRhVHlwZSI6IntodHRwOi8vaGw3Lm9yZy9maGlyfVBhdGllbnQiLCJ0ZW1wbGF0ZUlkIjoiaHR0cDovL2hsNy5vcmcvZmhpci9TdHJ1Y3R1cmVEZWZpbml0aW9uL1BhdGllbnQiLCJhbm5vdGF0aW9uIjpbXSwiaW5jbHVkZSI6W10sImNvZGVGaWx0ZXIiOltdLCJkYXRlRmlsdGVyIjpbXSwib3RoZXJGaWx0ZXIiOltdfX19LHsibmFtZSI6IkluSW5pdGlhbFBvcHVsYXRpb24iLCJjb250ZXh0IjoiUGF0aWVudCIsImFjY2Vzc0xldmVsIjoiUHVibGljIiwiYW5ub3RhdGlvbiI6W10sImV4cHJlc3Npb24iOnsidHlwZSI6IkxpdGVyYWwiLCJ2YWx1ZVR5cGUiOiJ7dXJuOmhsNy1vcmc6ZWxtLXR5cGVzOnIxfUJvb2xlYW4iLCJ2YWx1ZSI6InRydWUiLCJhbm5vdGF0aW9uIjpbXX19LHsibmFtZSI6IkluRGVub21pbmF0b3IiLCJjb250ZXh0IjoiUGF0aWVudCIsImFjY2Vzc0xldmVsIjoiUHVibGljIiwiYW5ub3RhdGlvbiI6W10sImV4cHJlc3Npb24iOnsidHlwZSI6IkxpdGVyYWwiLCJ2YWx1ZVR5cGUiOiJ7dXJuOmhsNy1vcmc6ZWxtLXR5cGVzOnIxfUJvb2xlYW4iLCJ2YWx1ZSI6InRydWUiLCJhbm5vdGF0aW9uIjpbXX19LHsibmFtZSI6IkluTnVtZXJhdG9yIiwiY29udGV4dCI6IlBhdGllbnQiLCJhY2Nlc3NMZXZlbCI6IlB1YmxpYyIsImFubm90YXRpb24iOltdLCJleHByZXNzaW9uIjp7InR5cGUiOiJMaXRlcmFsIiwidmFsdWVUeXBlIjoie3VybjpobDctb3JnOmVsbS10eXBlczpyMX1Cb29sZWFuIiwidmFsdWUiOiJ0cnVlIiwiYW5ub3RhdGlvbiI6W119fSx7Im5hbWUiOiJIYXNNYW1tYUNhIiwiY29udGV4dCI6IlBhdGllbnQiLCJhY2Nlc3NMZXZlbCI6IlB1YmxpYyIsImFubm90YXRpb24iOltdLCJleHByZXNzaW9uIjp7InR5cGUiOiJFeGlzdHMiLCJhbm5vdGF0aW9uIjpbXSwic2lnbmF0dXJlIjpbeyJ0eXBlIjoiTGlzdFR5cGVTcGVjaWZpZXIiLCJhbm5vdGF0aW9uIjpbXSwiZWxlbWVudFR5cGUiOnsidHlwZSI6Ik5hbWVkVHlwZVNwZWNpZmllciIsIm5hbWUiOiJ7aHR0cDovL2hsNy5vcmcvZmhpcn1Db25kaXRpb24iLCJhbm5vdGF0aW9uIjpbXX19XSwib3BlcmFuZCI6eyJ0eXBlIjoiUXVlcnkiLCJhbm5vdGF0aW9uIjpbXSwic291cmNlIjpbeyJhbGlhcyI6IkMiLCJhbm5vdGF0aW9uIjpbXSwiZXhwcmVzc2lvbiI6eyJ0eXBlIjoiUmV0cmlldmUiLCJkYXRhVHlwZSI6IntodHRwOi8vaGw3Lm9yZy9maGlyfUNvbmRpdGlvbiIsInRlbXBsYXRlSWQiOiJodHRwOi8vaGw3Lm9yZy9maGlyL1N0cnVjdHVyZURlZmluaXRpb24vQ29uZGl0aW9uIiwiYW5ub3RhdGlvbiI6W10sImluY2x1ZGUiOltdLCJjb2RlRmlsdGVyIjpbXSwiZGF0ZUZpbHRlciI6W10sIm90aGVyRmlsdGVyIjpbXX19XSwibGV0IjpbXSwicmVsYXRpb25zaGlwIjpbXSwid2hlcmUiOnsidHlwZSI6IkV4aXN0cyIsImFubm90YXRpb24iOltdLCJzaWduYXR1cmUiOltdLCJvcGVyYW5kIjp7InR5cGUiOiJRdWVyeSIsImFubm90YXRpb24iOltdLCJzb3VyY2UiOlt7ImFsaWFzIjoiYyIsImFubm90YXRpb24iOltdLCJleHByZXNzaW9uIjp7InR5cGUiOiJQcm9wZXJ0eSIsInBhdGgiOiJjb2RpbmciLCJhbm5vdGF0aW9uIjpbXSwic291cmNlIjp7InR5cGUiOiJQcm9wZXJ0eSIsInBhdGgiOiJjb2RlIiwic2NvcGUiOiJDIiwiYW5ub3RhdGlvbiI6W119fX1dLCJsZXQiOltdLCJyZWxhdGlvbnNoaXAiOltdLCJ3aGVyZSI6eyJ0eXBlIjoiQW5kIiwiYW5ub3RhdGlvbiI6W10sInNpZ25hdHVyZSI6W10sIm9wZXJhbmQiOlt7InR5cGUiOiJFcXVhbCIsImFubm90YXRpb24iOltdLCJzaWduYXR1cmUiOlt7InR5cGUiOiJOYW1lZFR5cGVTcGVjaWZpZXIiLCJuYW1lIjoie3VybjpobDctb3JnOmVsbS10eXBlczpyMX1TdHJpbmciLCJhbm5vdGF0aW9uIjpbXX0seyJ0eXBlIjoiTmFtZWRUeXBlU3BlY2lmaWVyIiwibmFtZSI6Int1cm46aGw3LW9yZzplbG0tdHlwZXM6cjF9U3RyaW5nIiwiYW5ub3RhdGlvbiI6W119XSwib3BlcmFuZCI6W3sidHlwZSI6IkZ1bmN0aW9uUmVmIiwibmFtZSI6IlRvU3RyaW5nIiwibGlicmFyeU5hbWUiOiJGSElSSGVscGVycyIsImFubm90YXRpb24iOltdLCJzaWduYXR1cmUiOlt7InR5cGUiOiJOYW1lZFR5cGVTcGVjaWZpZXIiLCJuYW1lIjoie2h0dHA6Ly9obDcub3JnL2ZoaXJ9dXJpIiwiYW5ub3RhdGlvbiI6W119XSwib3BlcmFuZCI6W3sidHlwZSI6IlByb3BlcnR5IiwicGF0aCI6InN5c3RlbSIsInNjb3BlIjoiYyIsImFubm90YXRpb24iOltdfV19LHsidHlwZSI6IkxpdGVyYWwiLCJ2YWx1ZVR5cGUiOiJ7dXJuOmhsNy1vcmc6ZWxtLXR5cGVzOnIxfVN0cmluZyIsInZhbHVlIjoiaHR0cDovL3Nub21lZC5pbmZvL3NjdCIsImFubm90YXRpb24iOltdfV19LHsidHlwZSI6IkVxdWFsIiwiYW5ub3RhdGlvbiI6W10sInNpZ25hdHVyZSI6W3sidHlwZSI6Ik5hbWVkVHlwZVNwZWNpZmllciIsIm5hbWUiOiJ7dXJuOmhsNy1vcmc6ZWxtLXR5cGVzOnIxfVN0cmluZyIsImFubm90YXRpb24iOltdfSx7InR5cGUiOiJOYW1lZFR5cGVTcGVjaWZpZXIiLCJuYW1lIjoie3VybjpobDctb3JnOmVsbS10eXBlczpyMX1TdHJpbmciLCJhbm5vdGF0aW9uIjpbXX1dLCJvcGVyYW5kIjpbeyJ0eXBlIjoiRnVuY3Rpb25SZWYiLCJuYW1lIjoiVG9TdHJpbmciLCJsaWJyYXJ5TmFtZSI6IkZISVJIZWxwZXJzIiwiYW5ub3RhdGlvbiI6W10sInNpZ25hdHVyZSI6W3sidHlwZSI6Ik5hbWVkVHlwZVNwZWNpZmllciIsIm5hbWUiOiJ7aHR0cDovL2hsNy5vcmcvZmhpcn1zdHJpbmciLCJhbm5vdGF0aW9uIjpbXX1dLCJvcGVyYW5kIjpbeyJ0eXBlIjoiUHJvcGVydHkiLCJwYXRoIjoiY29kZSIsInNjb3BlIjoiYyIsImFubm90YXRpb24iOltdfV19LHsidHlwZSI6IkxpdGVyYWwiLCJ2YWx1ZVR5cGUiOiJ7dXJuOmhsNy1vcmc6ZWxtLXR5cGVzOnIxfVN0cmluZyIsInZhbHVlIjoiMjU0ODM3MDA5IiwiYW5ub3RhdGlvbiI6W119XX1dfX19fX19LHsibmFtZSI6Ikhhc0JFVCIsImNvbnRleHQiOiJQYXRpZW50IiwiYWNjZXNzTGV2ZWwiOiJQdWJsaWMiLCJhbm5vdGF0aW9uIjpbXSwiZXhwcmVzc2lvbiI6eyJ0eXBlIjoiRXhpc3RzIiwiYW5ub3RhdGlvbiI6W10sInNpZ25hdHVyZSI6W3sidHlwZSI6Ikxpc3RUeXBlU3BlY2lmaWVyIiwiYW5ub3RhdGlvbiI6W10sImVsZW1lbnRUeXBlIjp7InR5cGUiOiJOYW1lZFR5cGVTcGVjaWZpZXIiLCJuYW1lIjoie2h0dHA6Ly9obDcub3JnL2ZoaXJ9UHJvY2VkdXJlIiwiYW5ub3RhdGlvbiI6W119fV0sIm9wZXJhbmQiOnsidHlwZSI6IlF1ZXJ5IiwiYW5ub3RhdGlvbiI6W10sInNvdXJjZSI6W3siYWxpYXMiOiJQIiwiYW5ub3RhdGlvbiI6W10sImV4cHJlc3Npb24iOnsidHlwZSI6IlJldHJpZXZlIiwiZGF0YVR5cGUiOiJ7aHR0cDovL2hsNy5vcmcvZmhpcn1Qcm9jZWR1cmUiLCJ0ZW1wbGF0ZUlkIjoiaHR0cDovL2hsNy5vcmcvZmhpci9TdHJ1Y3R1cmVEZWZpbml0aW9uL1Byb2NlZHVyZSIsImFubm90YXRpb24iOltdLCJpbmNsdWRlIjpbXSwiY29kZUZpbHRlciI6W10sImRhdGVGaWx0ZXIiOltdLCJvdGhlckZpbHRlciI6W119fV0sImxldCI6W10sInJlbGF0aW9uc2hpcCI6W10sIndoZXJlIjp7InR5cGUiOiJFeGlzdHMiLCJhbm5vdGF0aW9uIjpbXSwic2lnbmF0dXJlIjpbeyJ0eXBlIjoiTGlzdFR5cGVTcGVjaWZpZXIiLCJhbm5vdGF0aW9uIjpbXSwiZWxlbWVudFR5cGUiOnsidHlwZSI6Ik5hbWVkVHlwZVNwZWNpZmllciIsIm5hbWUiOiJ7aHR0cDovL2hsNy5vcmcvZmhpcn1Db2RpbmciLCJhbm5vdGF0aW9uIjpbXX19XSwib3BlcmFuZCI6eyJ0eXBlIjoiUXVlcnkiLCJhbm5vdGF0aW9uIjpbXSwic291cmNlIjpbeyJhbGlhcyI6ImMiLCJhbm5vdGF0aW9uIjpbXSwiZXhwcmVzc2lvbiI6eyJ0eXBlIjoiUHJvcGVydHkiLCJwYXRoIjoiY29kaW5nIiwiYW5ub3RhdGlvbiI6W10sInNvdXJjZSI6eyJ0eXBlIjoiUHJvcGVydHkiLCJwYXRoIjoiY29kZSIsInNjb3BlIjoiUCIsImFubm90YXRpb24iOltdfX19XSwibGV0IjpbXSwicmVsYXRpb25zaGlwIjpbXSwid2hlcmUiOnsidHlwZSI6IkFuZCIsImFubm90YXRpb24iOltdLCJzaWduYXR1cmUiOltdLCJvcGVyYW5kIjpbeyJ0eXBlIjoiRXF1YWwiLCJhbm5vdGF0aW9uIjpbXSwic2lnbmF0dXJlIjpbeyJ0eXBlIjoiTmFtZWRUeXBlU3BlY2lmaWVyIiwibmFtZSI6Int1cm46aGw3LW9yZzplbG0tdHlwZXM6cjF9U3RyaW5nIiwiYW5ub3RhdGlvbiI6W119LHsidHlwZSI6Ik5hbWVkVHlwZVNwZWNpZmllciIsIm5hbWUiOiJ7dXJuOmhsNy1vcmc6ZWxtLXR5cGVzOnIxfVN0cmluZyIsImFubm90YXRpb24iOltdfV0sIm9wZXJhbmQiOlt7InR5cGUiOiJGdW5jdGlvblJlZiIsIm5hbWUiOiJUb1N0cmluZyIsImxpYnJhcnlOYW1lIjoiRkhJUkhlbHBlcnMiLCJhbm5vdGF0aW9uIjpbXSwic2lnbmF0dXJlIjpbeyJ0eXBlIjoiTmFtZWRUeXBlU3BlY2lmaWVyIiwibmFtZSI6IntodHRwOi8vaGw3Lm9yZy9maGlyfXVyaSIsImFubm90YXRpb24iOltdfV0sIm9wZXJhbmQiOlt7InR5cGUiOiJQcm9wZXJ0eSIsInBhdGgiOiJzeXN0ZW0iLCJzY29wZSI6ImMiLCJhbm5vdGF0aW9uIjpbXX1dfSx7InR5cGUiOiJMaXRlcmFsIiwidmFsdWVUeXBlIjoie3VybjpobDctb3JnOmVsbS10eXBlczpyMX1TdHJpbmciLCJ2YWx1ZSI6Imh0dHA6Ly9maGlyLmRlL0NvZGVTeXN0ZW0vYmZhcm0vb3BzIiwiYW5ub3RhdGlvbiI6W119XX0seyJ0eXBlIjoiU3RhcnRzV2l0aCIsImFubm90YXRpb24iOltdLCJzaWduYXR1cmUiOltdLCJvcGVyYW5kIjpbeyJ0eXBlIjoiRnVuY3Rpb25SZWYiLCJuYW1lIjoiVG9TdHJpbmciLCJsaWJyYXJ5TmFtZSI6IkZISVJIZWxwZXJzIiwiYW5ub3RhdGlvbiI6W10sInNpZ25hdHVyZSI6W3sidHlwZSI6Ik5hbWVkVHlwZVNwZWNpZmllciIsIm5hbWUiOiJ7aHR0cDovL2hsNy5vcmcvZmhpcn1zdHJpbmciLCJhbm5vdGF0aW9uIjpbXX1dLCJvcGVyYW5kIjpbeyJ0eXBlIjoiUHJvcGVydHkiLCJwYXRoIjoiY29kZSIsInNjb3BlIjoiYyIsImFubm90YXRpb24iOltdfV19LHsidHlwZSI6IkxpdGVyYWwiLCJ2YWx1ZVR5cGUiOiJ7dXJuOmhsNy1vcmc6ZWxtLXR5cGVzOnIxfVN0cmluZyIsInZhbHVlIjoiNS04NzAiLCJhbm5vdGF0aW9uIjpbXX1dfV19fX19fX1dfX19",
    "title" : "MinimalMeasureLib.elm.json"
  }]
}

```
