# Nachsorge & Verlauf - Kerndatensatz Senologie v0.10.0

* [**Table of Contents**](toc.md)
* [**Datenmodell**](datenmodell.md)
* **Nachsorge & Verlauf**

## Nachsorge & Verlauf

![](senologie-nachsorge.png)

### Klinische Nachsorge vs. Verlaufsmeldung

In der Senologie treffen zwei unterschiedliche Perspektiven auf den Verlauf zusammen:

* **Klinische Nachsorge**: Regelmäßige Kontrollen (Mammographie, klinische Untersuchung, ggf. Labor) zur Früherkennung von Rezidiven. Findet am Brustzentrum oder beim niedergelassenen Gynäkologen statt.
* **Verlaufsmeldung**: Strukturierte Rückmeldung an Register und Zertifizierungsstellen über den Tumorstatus zu definierten Zeitpunkten. Beantwortet die Frage: Lebt die Patientin, ist der Tumor in Remission, gibt es ein Rezidiv oder Metastasen?

Beide Perspektiven greifen auf teilweise gleiche Informationen zurück, bedienen aber unterschiedliche Zwecke und Empfänger.

### Klinische Nachsorge

Die Nachsorge folgt den S3-Leitlinien-Empfehlungen und umfasst typischerweise:

* Klinische Untersuchung alle 3–6 Monate in den ersten 3 Jahren, dann jährlich
* Mammographie / Bildgebung jährlich
* Anamnese zu Symptomen, Lebensqualität, Therapie-Compliance (v.a. endokrine Therapie)
* Laborkontrollen bei Indikation

Die klinischen Befunde aus der Nachsorge fließen in die Verlaufsbeurteilung ein.

### Verlaufsmeldung

Für Krebsregister (oBDS) und DKG-Zertifizierung (OncoBox) ist eine strukturierte Verlaufsmeldung erforderlich:

| | |
| :--- | :--- |
| Tumorstatus lokal | Kein Tumor, Tumorreste, Lokalrezidiv, Progress |
| Tumorstatus Lymphknoten | Regionärer Befall ja/nein/Progress |
| Tumorstatus Fernmetastasen | Fernmetastasen ja/nein/Progress |
| Gesamtbeurteilung | Vollremission, Teilremission, Stable Disease, Progress |
| Vitalstatus | Lebend, verstorben, unbekannt |

Diese Beurteilung wird durch den behandelnden Arzt auf Basis der verfügbaren klinischen Informationen vorgenommen.

### Abgrenzung und offene Fragen

Einige Datenpunkte der Verlaufsmeldung — etwa die Art der Nachsorge (aktiv: Patientin persönlich untersucht vs. passiv: Information aus Akten oder Registern) — liegen zwischen klinischer Dokumentation und Meldewesen. Sie werden im Verlauf-Questionnaire als Feld erfasst, da die Unterscheidung zum Zeitpunkt der Dokumentation bekannt ist.

Die genaue Abgrenzung, welche Verlaufsinformationen klinisch dokumentiert und welche erst bei der Meldungserstellung ergänzt werden, ist Gegenstand der weiteren Ausgestaltung dieses Moduls.

### Zugehörige Ressourcen

| | |
| :--- | :--- |
| Profil | [Senologie_FollowUp](StructureDefinition-senologie-follow-up.md) |
| Profil | [Senologie_Psychoonkologie](StructureDefinition-senologie-psychoonkologie.md) |
| Profil | [Senologie_Sozialdienst](StructureDefinition-senologie-sozialdienst.md) |
| Questionnaire | [Verlauf](Questionnaire-senologie-verlauf.md) |
| Beispiel | [Fall 1 — Verlauf 6 Monate](Observation-Fall1-Verlauf-6Monate.md) |
| Beispiel | [Fall 1 — ECOG](Observation-Fall1-ECOG-6Monate.md) |

