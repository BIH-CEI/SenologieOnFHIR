# SenologieToObdsST - Kerndatensatz Senologie v0.10.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SenologieToObdsST**

## StructureMap: SenologieToObdsST 

| | |
| :--- | :--- |
| **:https://www.senologie.org/fhir/StructureMap/SenologieToObdsST | **:0.10.0 |
| Draft | **:SenologieToObdsST |

 
title: Senologie FHIR to oBDS Strahlentherapie (ST) status: draft 



## Resource Content

```json
{
  "resourceType" : "StructureMap",
  "id" : "SenologieToObdsST",
  "url" : "https://www.senologie.org/fhir/StructureMap/SenologieToObdsST",
  "version" : "0.10.0",
  "name" : "SenologieToObdsST",
  "status" : "draft",
  "date" : "2026-10-19T00:09:05+00:00",
  "publisher" : "Berlin Institute of Health at Charité (BIH)",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "Berlin Institute of Health at Charité (BIH)"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Berlin Institute of Health at Charité (BIH)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org"
    }]
  }],
  "description" : "title: Senologie FHIR to oBDS Strahlentherapie (ST)\r\nstatus: draft",
  "structure" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/Bundle",
    "mode" : "source",
    "alias" : "Bundle"
  },
  {
    "url" : "https://www.senologie.org/fhir/StructureDefinition/obds-meldung",
    "mode" : "target",
    "alias" : "OBDSMeldung"
  }],
  "import" : ["https://www.senologie.org/fhir/StructureMap/SenologieToObdsTumorzuordnung",
  "https://www.senologie.org/fhir/StructureMap/SenologieToObdsNebenwirkung"],
  "group" : [{
    "name" : "SenologieToObdsST",
    "typeMode" : "none",
    "documentation" : "Known limitation: Sub-groups (MapST, MapBestrahlung) use\r\n`target tgt : BackboneElement` because FML has no syntax to declare the\r\nLogical Model sub-path for BackboneElement slices passed from parent groups.\r\nThe IG Publisher produces SM_TARGET_PATH errors (~19). The element names are\r\ncorrect per the oBDS Logical Model.\r\n============================================================================\r\nHauptgruppe: Bundle → oBDS ST (Strahlentherapie)\r\nEin Bundle enthaelt Strahlentherapie-Procedures (einzelne Bestrahlungsserien)\r\nund ggf. Observations fuer Nebenwirkungen (CTCAE).\r\n============================================================================",
    "input" : [{
      "name" : "src",
      "type" : "Bundle",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "OBDSMeldung",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "EntryST",
      "source" : [{
        "context" : "src",
        "element" : "entry",
        "variable" : "entry",
        "condition" : "resource.is(Procedure) and resource.meta.profile.exists($this.contains('senologie-strahlentherapie'))"
      }],
      "rule" : [{
        "name" : "CallMapST",
        "source" : [{
          "context" : "entry",
          "element" : "resource",
          "variable" : "proc"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "st",
          "variable" : "st"
        }],
        "dependent" : [{
          "name" : "MapST",
          "variable" : ["proc", "st"]
        }]
      },
      {
        "name" : "CallMapNebenwirkungen",
        "source" : [{
          "context" : "entry",
          "element" : "resource",
          "variable" : "proc2"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "st",
          "variable" : "st2"
        },
        {
          "context" : "st2",
          "contextType" : "variable",
          "element" : "nebenwirkungen",
          "variable" : "nw"
        }],
        "dependent" : [{
          "name" : "MapNebenwirkungenST",
          "variable" : ["src", "nw"]
        }],
        "documentation" : "Nebenwirkungen (moved from MapST)"
      }],
      "documentation" : "Strahlentherapie-Procedure extrahieren"
    }]
  },
  {
    "name" : "MapST",
    "typeMode" : "none",
    "documentation" : "============================================================================\r\nMapST: Procedure → oBDS ST Basisdaten\r\nMapped Intention, Stellung zur OP und erzeugt Bestrahlungs-Eintraege\r\n============================================================================",
    "input" : [{
      "name" : "src",
      "type" : "Procedure",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "BackboneElement",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "SetStID",
      "source" : [{
        "context" : "src",
        "element" : "id",
        "variable" : "id"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "stID",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "id"
        }]
      }],
      "documentation" : "ST_ID: Procedure.id"
    },
    {
      "name" : "MeldeanlassEnde",
      "source" : [{
        "context" : "src",
        "condition" : "performedPeriod.end.exists()"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "meldeanlass",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "behandlungsende"
        }]
      }],
      "documentation" : "Meldeanlass: abgeleitet aus vorhandenem Enddatum"
    },
    {
      "name" : "MeldeanlassBeginn",
      "source" : [{
        "context" : "src",
        "condition" : "performedPeriod.end.exists().not()"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "meldeanlass",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "behandlungsbeginn"
        }]
      }]
    },
    {
      "name" : "MapIntention",
      "source" : [{
        "context" : "src",
        "element" : "extension",
        "variable" : "ext",
        "condition" : "url = 'https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-intention'"
      }],
      "rule" : [{
        "name" : "ExtractIntentionCoding",
        "source" : [{
          "context" : "ext",
          "element" : "value",
          "variable" : "val"
        }],
        "rule" : [{
          "name" : "ExtractIntentionCode",
          "source" : [{
            "context" : "val",
            "element" : "coding",
            "variable" : "c"
          }],
          "rule" : [{
            "name" : "SetIntention",
            "source" : [{
              "context" : "c",
              "element" : "code",
              "variable" : "cd"
            }],
            "target" : [{
              "context" : "tgt",
              "contextType" : "variable",
              "element" : "intention",
              "transform" : "copy",
              "parameter" : [{
                "valueId" : "cd"
              }]
            }]
          }]
        }]
      }],
      "documentation" : "Intention: aus MII Onko Strahlentherapie-Intention Extension\r\nMII Onko CodeSystem nutzt bereits oBDS-Codes (K, P, D, R, S, X)"
    },
    {
      "name" : "MapStellungOP",
      "source" : [{
        "context" : "src",
        "element" : "category",
        "variable" : "cat"
      }],
      "rule" : [{
        "name" : "ExtractStellungCode",
        "source" : [{
          "context" : "cat",
          "element" : "coding",
          "variable" : "c",
          "condition" : "system = 'https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-therapie-stellungzurop'"
        }],
        "rule" : [{
          "name" : "SetStellungOP",
          "source" : [{
            "context" : "c",
            "element" : "code",
            "variable" : "cd"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "stellungOP",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "cd"
            }]
          }]
        }]
      }],
      "documentation" : "Stellung zur OP: aus Procedure.category (MII Onko StellungZurOp)\r\nMII Onko CodeSystem nutzt bereits oBDS-Codes (O, A, N, I, S)"
    },
    {
      "name" : "CallMapBestrahlung",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "bestrahlungen",
        "variable" : "best"
      }],
      "dependent" : [{
        "name" : "MapBestrahlung",
        "variable" : ["src", "best"]
      }],
      "documentation" : "Bestrahlung: jede Procedure bildet eine einzelne Bestrahlungsserie ab\r\nIm Senologie-Profil ist jede Procedure eine Bestrahlung"
    },
    {
      "name" : "MapEndeGrund",
      "source" : [{
        "context" : "src",
        "element" : "outcome",
        "variable" : "oc"
      }],
      "rule" : [{
        "name" : "SetEndeGrundCode",
        "source" : [{
          "context" : "oc",
          "element" : "coding",
          "variable" : "c"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "endeGrund",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "c.code"
          }]
        }]
      }],
      "documentation" : "Ende-Grund: aus Procedure.outcome.coding"
    }]
  },
  {
    "name" : "MapBestrahlung",
    "typeMode" : "none",
    "documentation" : "============================================================================\r\nMapBestrahlung: Procedure → oBDS Bestrahlung\r\nExtrahiert Bestrahlungsdetails: Zeitraum, Applikationsart, Zielgebiet,\r\nDosis und Boost aus den MII Onko Extensions\r\n============================================================================",
    "input" : [{
      "name" : "src",
      "type" : "Procedure",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "BackboneElement",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "MapBestrahlungBeginn",
      "source" : [{
        "context" : "src",
        "element" : "performed",
        "variable" : "perf"
      }],
      "rule" : [{
        "name" : "SetBestrahlungBeginn",
        "source" : [{
          "context" : "perf",
          "element" : "start",
          "variable" : "s"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "beginn",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "s"
          }]
        }]
      }],
      "documentation" : "Beginn: aus performedPeriod.start"
    },
    {
      "name" : "MapBestrahlungEnde",
      "source" : [{
        "context" : "src",
        "element" : "performed",
        "variable" : "perf"
      }],
      "rule" : [{
        "name" : "SetBestrahlungEnde",
        "source" : [{
          "context" : "perf",
          "element" : "end",
          "variable" : "e"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "ende",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "e"
          }]
        }]
      }],
      "documentation" : "Ende: aus performedPeriod.end"
    },
    {
      "name" : "MapApplikationsart",
      "source" : [{
        "context" : "src",
        "element" : "code",
        "variable" : "code"
      }],
      "rule" : [{
        "name" : "ApplikationsartPerkutan",
        "source" : [{
          "context" : "code",
          "element" : "coding",
          "variable" : "c",
          "condition" : "code.startsWith('8-522')"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "applikationsart",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "P"
          }]
        }]
      },
      {
        "name" : "ApplikationsartKontakt",
        "source" : [{
          "context" : "code",
          "element" : "coding",
          "variable" : "c",
          "condition" : "code.startsWith('8-524')"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "applikationsart",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "K"
          }]
        }]
      }],
      "documentation" : "Applikationsart: aus Procedure.code oder MII Extension\r\nPerkutan vs. Kontakt (Brachytherapie)\r\nOPS 8-522 = Perkutane Hochvoltstrahlentherapie\r\nOPS 8-524 = Brachytherapie"
    },
    {
      "name" : "MapZielgebiet",
      "source" : [{
        "context" : "src",
        "element" : "bodySite",
        "variable" : "bs"
      }],
      "rule" : [{
        "name" : "ExtractZielgebietCoding",
        "source" : [{
          "context" : "bs",
          "element" : "coding",
          "variable" : "c"
        }],
        "rule" : [{
          "name" : "SetZielgebiet",
          "source" : [{
            "context" : "c",
            "element" : "display",
            "variable" : "d"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "zielgebiet",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "d"
            }]
          }]
        }]
      }],
      "documentation" : "Zielgebiet: aus Procedure.bodySite.coding"
    },
    {
      "name" : "MapSeiteZielgebiet",
      "source" : [{
        "context" : "src",
        "element" : "bodySite",
        "variable" : "bs"
      }],
      "rule" : [{
        "name" : "MapSeiteExtension",
        "source" : [{
          "context" : "bs",
          "element" : "extension",
          "variable" : "ext",
          "condition" : "url = 'https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-seitenlokalisation'"
        }],
        "rule" : [{
          "name" : "ExtractSeiteCoding",
          "source" : [{
            "context" : "ext",
            "element" : "value",
            "variable" : "val"
          }],
          "rule" : [{
            "name" : "TranslateSeiteZielgebiet",
            "source" : [{
              "context" : "val",
              "element" : "coding",
              "variable" : "c"
            }],
            "target" : [{
              "context" : "tgt",
              "contextType" : "variable",
              "element" : "seiteZielgebiet",
              "transform" : "translate",
              "parameter" : [{
                "valueId" : "c"
              },
              {
                "valueString" : "https://www.senologie.org/fhir/ConceptMap/cm-sct-to-obds-seitenlokalisation"
              },
              {
                "valueString" : "code"
              }]
            }]
          }]
        }]
      }],
      "documentation" : "Seite des Zielgebiets: aus bodySite-Extension Seitenlokalisation\r\noder abgeleitet aus bodySite-SNOMED-Code (z.B. \"Left breast\")"
    },
    {
      "name" : "MapGesamtdosis",
      "source" : [{
        "context" : "src",
        "element" : "extension",
        "variable" : "ext",
        "condition" : "url = 'https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-gesamtdosis'"
      }],
      "rule" : [{
        "name" : "ExtractGesamtdosisValue",
        "source" : [{
          "context" : "ext",
          "element" : "value",
          "variable" : "val"
        }],
        "rule" : [{
          "name" : "SetGesamtdosis",
          "source" : [{
            "context" : "val",
            "element" : "value",
            "variable" : "v"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "gesamtdosis",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "v"
            }]
          }]
        },
        {
          "name" : "SetGesamtdosisEinheit",
          "source" : [{
            "context" : "val",
            "element" : "unit",
            "variable" : "u"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "gesamtdosisEinheit",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "u"
            }]
          }]
        }]
      }],
      "documentation" : "Gesamtdosis: aus MII Onko Gesamtdosis-Extension"
    },
    {
      "name" : "MapEinzeldosis",
      "source" : [{
        "context" : "src",
        "element" : "extension",
        "variable" : "ext",
        "condition" : "url = 'https://www.senologie.org/fhir/StructureDefinition/ex-senologie-einzeldosis'"
      }],
      "rule" : [{
        "name" : "ExtractEinzeldosisValue",
        "source" : [{
          "context" : "ext",
          "element" : "value",
          "variable" : "val"
        }],
        "rule" : [{
          "name" : "SetEinzeldosis",
          "source" : [{
            "context" : "val",
            "element" : "value",
            "variable" : "v"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "einzeldosis",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "v"
            }]
          }]
        },
        {
          "name" : "SetEinzeldosisEinheit",
          "source" : [{
            "context" : "val",
            "element" : "unit",
            "variable" : "u"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "einzeldosisEinheit",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "u"
            }]
          }]
        }]
      }],
      "documentation" : "Einzeldosis: aus Senologie Einzeldosis-Extension"
    },
    {
      "name" : "MapBoost",
      "source" : [{
        "context" : "src",
        "element" : "extension",
        "variable" : "ext",
        "condition" : "url = 'https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-boost'"
      }],
      "rule" : [{
        "name" : "ExtractBoostCoding",
        "source" : [{
          "context" : "ext",
          "element" : "value",
          "variable" : "val"
        }],
        "rule" : [{
          "name" : "SetBoost",
          "source" : [{
            "context" : "val",
            "element" : "coding",
            "variable" : "c"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "boost",
            "transform" : "evaluate",
            "parameter" : [{
              "valueString" : "c.code"
            }]
          }]
        }]
      }],
      "documentation" : "Boost: aus MII Onko Boost-Extension\r\nJ=ja, N=nein, SIB=simultan integrierter Boost"
    }]
  }]
}

```
