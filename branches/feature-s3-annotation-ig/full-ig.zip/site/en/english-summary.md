# English Summary - Kerndatensatz Senologie v0.10.0

* [**Table of Contents**](toc.md)
* **English Summary**

## English Summary

 This page includes translations from the original source language in which the guide was authored. Information on these translations and instructions on how to provide feedback on the translations can be found [here](translationinfo.html). 

### Senologie Core Dataset — English Summary

> The guide is available in German and English; use the language switch in the top right corner.

> **Note:** The full Implementation Guide is published in German, reflecting its primary audience (German-certified breast cancer centres and their reporting context). This page summarises the specification for an international audience. All FHIR artefacts (profiles, ValueSets, examples) carry English titles and descriptions where applicable.

The **Senologie Core Dataset** defines FHIR R4 profiles for the structured documentation of breast cancer care at certified breast centres in Germany. It covers the entire care pathway — from initial presentation through diagnostics, therapy, and follow-up. The specification is developed by the **Berlin Institute of Health at Charité (BIH)** in coordination with the **German Society for Senology (DGS)**, **DGGG**, and **AGO**.

#### Scope at a glance

| | | |
| :--- | :--- | :--- |
| **Diagnosis** | Initial diagnosis, recurrence, cTNM staging, laterality | [Diagnose](StructureDefinition-senologie-diagnose-maligne.md) |
| **Diagnostics** | Imaging (mammography, ultrasound, MRI), pathology, biomarkers | [Bildgebung](StructureDefinition-senologie-bildgebung-befund.md),[Pathologie](StructureDefinition-senologie-pathologie-befund.md) |
| **Therapy** | Surgery, systemic therapy, radiotherapy | [Operation](StructureDefinition-senologie-operation.md),[Systemtherapie](StructureDefinition-senologie-systemtherapie-procedure.md) |
| **Tumour board** | Treatment recommendations, multidisciplinary review | [Tumorboard](StructureDefinition-senologie-tumorboard-empfehlung.md) |
| **Follow-up** | Surveillance, vital status, recurrence monitoring | [Follow-Up](StructureDefinition-senologie-follow-up.md) |

#### Design principles

* **Form-first capture.** Data is entered via SDC Questionnaires aligned with clinical workflow; FHIR resources are derived by SDC template-based extraction.
* **Built on MII profiles.** The dataset reuses the Medical Informatics Initiative (MII) core modules (Onkologie, Pathologie, Bildgebung) as its technical base rather than redefining them. It is a stand-alone dataset, not an MII module.
* **ISiK-compatible.** Profiles inherit from ISiK base profiles where applicable, so resources can flow into German hospital interoperability layers without rework.
* **Secondary use.** Captured data feeds quality reporting, registry submissions, and research without re-entry.

#### German reporting datasets — context for international readers

A defining requirement for German breast centres is that the same clinical record must serve multiple mandatory reporting pipelines. The IG provides mappings from the FHIR resources to each of these. They are listed here so international readers understand the regulatory backdrop; full mapping details live on the [Meldedatensätze](anwendungsfaelle-meldedatensaetze.md) pages of the German IG.

| | | |
| :--- | :--- | :--- |
| **oBDS**(Onkologischer Basisdatensatz) | Cancer registries (statutory) | The minimum oncology dataset all hospitals must submit to regional cancer registries. Covers diagnosis, treatment, course of disease, and tumour-related death. |
| **IQTIG QS 18/1 Mammachirurgie** | Federal quality assurance | External inpatient quality assurance for breast surgery. Captures perioperative process and outcome indicators (e.g. preoperative imaging, axillary staging, completeness of resection). |
| **OncoBox Brust**(DKG) | DKG certification (voluntary) | Indicator set used by the German Cancer Society (Deutsche Krebsgesellschaft) to certify breast centres. Tracks adherence to S3-guideline-based quality benchmarks. |
| **IRegG** | Federal implant registry (statutory) | Mandatory reporting of breast implants to the German Implant Registry (Implantateregister Deutschland), including device identification, indication, and revision status. |

The relevant **logical-model mappings** to these datasets are published as `Mapping` blocks on the [Logical Model](StructureDefinition-LogicalModelSenologie-mappings.md).

#### Clinical guideline alignment

Clinical content follows the **S3 guideline for breast cancer** (AWMF 032-045OL), maintained jointly by the German Cancer Society (DKG), German Cancer Aid (DKH), and AWMF. ValueSets and required elements reflect the recommendations of the current guideline version.

#### Where to look next

* **[Data model](datenmodell.md)** — Logical model and FHIR resource model
* **[Profiles](profilbeschreibungen.md)** — All FHIR profiles
* **[Use cases](anwendungsfaelle-uebersicht.md)** — Capture, exchange, secondary use, reporting
* **[Terminology](terminologie-uebersicht.md)** — ValueSets, CodeSystems, ConceptMaps
* **[Artifacts](artifacts.md)** — Full list of FHIR artefacts

For interoperability questions or international collaboration, see [Interoperability](interoperabilitaet.md) (covers MII KDS, ISiK, IPS, EU-EHDS alignment).

#### Rights and licence

© Deutsche Gesellschaft für Senologie (DGS). The guide and its repository are provided by the Berlin Institute of Health at Charité (BIH) and licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). It builds on standards and terminologies owned by others, which that licence does not cover:

* **HL7 FHIR:** HL7® and FHIR® are registered trademarks of Health Level Seven International.
* **SNOMED CT:** This material includes SNOMED Clinical Terms® (SNOMED CT®), which is used by permission of SNOMED International. All rights reserved. "SNOMED" and "SNOMED CT" are registered trademarks of SNOMED International. Implementers must have the appropriate SNOMED CT Affiliate Licence.
* **LOINC:** This material contains content from LOINC® ([https://loinc.org](https://loinc.org)). LOINC is copyright © 1995-2026, Regenstrief Institute, Inc. and the LOINC Committee, and is available at no cost under the licence at [https://loinc.org/license](https://loinc.org/license).
* **Others:** ICD-10-GM and OPS (BfArM), ICD-O-3 (WHO), the UICC TNM classification and the reporting specifications remain under the terms of their owners.

#### Contact

* **Berlin Institute of Health at Charité (BIH)** — Core Unit eHealth & Interoperability
* GitHub: [BIH-CEI/SenologieOnFHIR](https://github.com/BIH-CEI/SenologieOnFHIR)

