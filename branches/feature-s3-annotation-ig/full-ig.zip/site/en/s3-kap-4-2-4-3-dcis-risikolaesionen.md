# Kap. 4.2–4.3 — DCIS und Risikoläsionen (B3) - Kerndatensatz Senologie v0.10.0

* [**Table of Contents**](toc.md)
* [**Terminology**](terminologie-uebersicht.md)
* [**S3-Leitlinien-Abdeckung**](leitlinien-abdeckung.md)
* **Kap. 4.2–4.3 — DCIS und Risikoläsionen (B3)**

## Kap. 4.2–4.3 — DCIS und Risikoläsionen (B3)

 This page includes translations from the original source language in which the guide was authored. Information on these translations and instructions on how to provide feedback on the translations can be found [here](translationinfo.html). 

### S3 Guideline v5.0 — Chapter 4.2–4.3: DCIS and risk lesions (B3)

The German page carries the annotation of this chapter: one block per recommendation with the original German wording, the data objects it requires, their terminology codes, and the mapping to the Senologie FHIR profiles.

**English translation pending.** This page exists in German only for now. The guideline annotation is going through clinical validation first: the recommendations, the assigned terminology codes and the gap assessment may still change, and translating them now would mean re-translating them afterwards. The English version follows once the German content has been clinically confirmed.

* [German version of this page](../de/s3-kap-4-2-4-3-dcis-risikolaesionen.md)
* [Glossary (SNOMED + S3)](glossar-s3-snomed.md) — the coded terms of all chapters, generated in English as well
* [Annotation schema](leitlinien-annotation-schema.md) — how to read the YAML blocks (German)

