# CM SNOMED CT Brustquadrant zu ICD-O-3 Topographie - Kerndatensatz Senologie v0.10.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CM SNOMED CT Brustquadrant zu ICD-O-3 Topographie**

## ConceptMap: CM SNOMED CT Brustquadrant zu ICD-O-3 Topographie 

| | |
| :--- | :--- |
| *Official URL*:https://www.senologie.org/fhir/ConceptMap/cm-sct-to-icdo3-mamma-topographie | *Version*:0.10.0 |
| Draft as of 2026-10-12 | *Computable Name*:CM_SCT_To_ICDO3_Mamma_Topographie |

 
Übersetzung der SNOMED-CT-kodierten Brustquadranten in ICD-O-3 Topographie-Codes (C50.0–C50.9) für die oBDS-Krebsregistermeldung. Quelle: BodyStructure.locationQualifier[quadrant]. 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "cm-sct-to-icdo3-mamma-topographie",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCode" : "CC-BY-4.0"
    },
    {
      "extension" : [{
        "url" : "packageId",
        "valueId" : "kds-senologie"
      },
      {
        "url" : "version",
        "valueString" : "0.10.0"
      },
      {
        "url" : "uri",
        "valueUri" : "https://www.senologie.org/fhir"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    }],
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareableconceptmap",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishableconceptmap"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "version" : "3.0.0",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C4872",
        "display" : "Breast Carcinoma"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "name" : "Berlin Institute of Health at Charité (BIH)",
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Berlin Institute of Health at Charité (BIH)",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.bihealth.org"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Deutsche Gesellschaft für Senologie (DGS)",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.senologie.org"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Deutsche Gesellschaft für Senologie (DGS)",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.senologie.org"
      }]
    }
  }],
  "url" : "https://www.senologie.org/fhir/ConceptMap/cm-sct-to-icdo3-mamma-topographie",
  "version" : "0.10.0",
  "name" : "CM_SCT_To_ICDO3_Mamma_Topographie",
  "title" : "CM SNOMED CT Brustquadrant zu ICD-O-3 Topographie",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-10-12",
  "publisher" : "Berlin Institute of Health at Charité (BIH)",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "Berlin Institute of Health at Charité (BIH)"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Berlin Institute of Health at Charité (BIH)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org"
    }]
  }],
  "description" : "Übersetzung der SNOMED-CT-kodierten Brustquadranten in ICD-O-3 Topographie-Codes (C50.0–C50.9) für die oBDS-Krebsregistermeldung. Quelle: BodyStructure.locationQualifier[quadrant].",
  "group" : [{
    "source" : "http://snomed.info/sct",
    "target" : "http://terminology.hl7.org/CodeSystem/icd-o-3",
    "element" : [{
      "code" : "279007000",
      "display" : "Nipple structure",
      "target" : [{
        "code" : "C50.0",
        "display" : "Brustwarze und Warzenhof",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "49058007",
      "display" : "Central portion of breast",
      "target" : [{
        "code" : "C50.1",
        "display" : "Zentraler Drüsenkörper der Brustdrüse",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "77831004",
      "display" : "Upper inner quadrant of breast",
      "target" : [{
        "code" : "C50.2",
        "display" : "Oberer innerer Quadrant der Brustdrüse",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "19100000",
      "display" : "Lower inner quadrant of breast",
      "target" : [{
        "code" : "C50.3",
        "display" : "Unterer innerer Quadrant der Brustdrüse",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "76365002",
      "display" : "Upper outer quadrant of breast",
      "target" : [{
        "code" : "C50.4",
        "display" : "Oberer äußerer Quadrant der Brustdrüse",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "33564002",
      "display" : "Lower outer quadrant of breast",
      "target" : [{
        "code" : "C50.5",
        "display" : "Unterer äußerer Quadrant der Brustdrüse",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "38412008",
      "display" : "Axillary tail of breast",
      "target" : [{
        "code" : "C50.6",
        "display" : "Recessus axillaris der Brustdrüse",
        "equivalence" : "equivalent"
      }]
    }],
    "unmapped" : {
      "mode" : "fixed",
      "code" : "C50.9",
      "display" : "Brustdrüse, nicht näher bezeichnet"
    }
  }]
}

```
